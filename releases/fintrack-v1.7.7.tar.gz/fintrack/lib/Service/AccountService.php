<?php

declare(strict_types=1);

namespace OCA\FinTrack\Service;

use OCP\DB\QueryBuilder\IQueryBuilder;

class AccountService extends BaseService {

	public function __construct(
		\OCP\IDBConnection $db,
		private CategoryService $categoryService,
	) {
		parent::__construct($db);
	}

	protected function tableName(): string { return 'fintrack_accounts'; }

	/** Name of the auto-created account that records investment profit/loss. */
	public const INVESTMENT_GAINS_ACCOUNT_NAME = 'Investment Gains / Losses';
	public const INVESTMENT_GAINS_CATEGORY_NAME = 'Profit / Loss';

	protected function mapRow(array $row): array {
		return [
			'id'            => (int)$row['id'],
			'name'          => $row['name'],
			'type'          => $row['type'],
			'currency'      => $row['currency'],
			'description'   => $row['description'] ?? '',
			'icon'          => $row['icon'] ?? '',
			'color'         => $row['color'] ?? '#4f8ef7',
			'active'        => (bool)(int)$row['active'],
			'created'       => (int)$row['created_at'],
			'isInvestment'  => (bool)(int)($row['is_investment'] ?? 0),
			'purchasePrice' => isset($row['purchase_price']) && $row['purchase_price'] !== null ? (float)$row['purchase_price'] : null,
			'purchaseDate'  => isset($row['purchase_date']) && $row['purchase_date'] !== null ? (int)$row['purchase_date'] : null,
			'settledDate'   => isset($row['settled_date']) && $row['settled_date'] !== null ? (int)$row['settled_date'] : null,
			'settledPrice'  => isset($row['settled_price']) && $row['settled_price'] !== null ? (float)$row['settled_price'] : null,
		];
	}

	public function findAll(string $userId): array {
		$qb = $this->qb();
		$qb->select('*')->from('fintrack_accounts')
		   ->where($qb->expr()->eq('user_id', $qb->createNamedParameter($userId)))
		   ->orderBy('name', 'ASC');
		return $this->rowsToArray($qb->executeQuery());
	}

	public function create(string $userId, array $data): array {
		$isInvestment = !empty($data['isInvestment']);
		$qb = $this->qb();
		$qb->insert('fintrack_accounts')->values([
			'user_id'        => $qb->createNamedParameter($userId),
			'name'           => $qb->createNamedParameter($data['name'] ?? ''),
			'type'           => $qb->createNamedParameter($data['type'] ?? 'asset'),
			'currency'       => $qb->createNamedParameter(strtoupper($data['currency'] ?? 'USD')),
			'description'    => $qb->createNamedParameter($data['description'] ?? ''),
			'icon'           => $qb->createNamedParameter($data['icon'] ?? ''),
			'color'          => $qb->createNamedParameter($data['color'] ?? '#4f8ef7'),
			'active'         => $qb->createNamedParameter((int)($data['active'] ?? 1), IQueryBuilder::PARAM_INT),
			'created_at'     => $qb->createNamedParameter($this->now(), IQueryBuilder::PARAM_INT),
			'is_investment'  => $qb->createNamedParameter($isInvestment ? 1 : 0, IQueryBuilder::PARAM_INT),
			'purchase_price' => $qb->createNamedParameter($data['purchasePrice'] ?? null),
			'purchase_date'  => $qb->createNamedParameter(!empty($data['purchaseDate']) ? strtotime((string)$data['purchaseDate']) : null, IQueryBuilder::PARAM_INT),
		]);
		$qb->executeStatement();
		$id = (int)$this->db->lastInsertId('fintrack_accounts');

		// The Investment Gains / Losses account + Profit / Loss category are
		// created up front the first time someone adds an investment account,
		// so they exist by default rather than only appearing after a sale.
		if ($isInvestment) {
			$this->ensureInvestmentGainsAccount($userId);
			$this->categoryService->ensureCategory($userId, self::INVESTMENT_GAINS_CATEGORY_NAME, 'expense', '📊');
		}

		return $this->find($userId, $id);
	}

	public function update(string $userId, int $id, array $data): array {
		$this->assertOwner($userId, 'fintrack_accounts', $id);
		$isInvestment = !empty($data['isInvestment']);
		$qb = $this->qb();
		$qb->update('fintrack_accounts')
		   ->set('name',        $qb->createNamedParameter($data['name'] ?? ''))
		   ->set('type',        $qb->createNamedParameter($data['type'] ?? 'asset'))
		   ->set('currency',    $qb->createNamedParameter(strtoupper($data['currency'] ?? 'USD')))
		   ->set('description', $qb->createNamedParameter($data['description'] ?? ''))
		   ->set('icon',        $qb->createNamedParameter($data['icon'] ?? ''))
		   ->set('color',       $qb->createNamedParameter($data['color'] ?? '#4f8ef7'))
		   ->set('active',      $qb->createNamedParameter((int)($data['active'] ?? 1), IQueryBuilder::PARAM_INT))
		   ->set('is_investment',  $qb->createNamedParameter($isInvestment ? 1 : 0, IQueryBuilder::PARAM_INT))
		   ->set('purchase_price', $qb->createNamedParameter($data['purchasePrice'] ?? null))
		   ->set('purchase_date',  $qb->createNamedParameter(!empty($data['purchaseDate']) ? strtotime((string)$data['purchaseDate']) : null, IQueryBuilder::PARAM_INT))
		   ->where($qb->expr()->eq('id', $qb->createNamedParameter($id, IQueryBuilder::PARAM_INT)));
		$qb->executeStatement();

		if ($isInvestment) {
			$this->ensureInvestmentGainsAccount($userId);
			$this->categoryService->ensureCategory($userId, self::INVESTMENT_GAINS_CATEGORY_NAME, 'expense', '📊');
		}

		return $this->find($userId, $id);
	}

	public function find(string $userId, int $id): array {
		$this->assertOwner($userId, 'fintrack_accounts', $id);
		$qb = $this->qb();
		$qb->select('*')->from('fintrack_accounts')
		   ->where($qb->expr()->eq('id', $qb->createNamedParameter($id, IQueryBuilder::PARAM_INT)));
		$row = $qb->executeQuery()->fetch();
		return $this->mapRow($row);
	}

	public function delete(string $userId, int $id): void {
		$this->assertOwner($userId, 'fintrack_accounts', $id);
		$qb = $this->qb();
		$qb->delete('fintrack_accounts')
		   ->where($qb->expr()->eq('id', $qb->createNamedParameter($id, IQueryBuilder::PARAM_INT)));
		$qb->executeStatement();
	}

	/**
	 * Finds the default "Investment Gains / Losses" revenue account, creating
	 * it if it doesn't exist yet. Kept idempotent so it's safe to call before
	 * every investment sale, not just the first investment account created.
	 */
	public function ensureInvestmentGainsAccount(string $userId): array {
		$qb = $this->qb();
		$qb->select('*')->from('fintrack_accounts')
		   ->where($qb->expr()->eq('user_id', $qb->createNamedParameter($userId)))
		   ->andWhere($qb->expr()->eq('name', $qb->createNamedParameter(self::INVESTMENT_GAINS_ACCOUNT_NAME)));
		$row = $qb->executeQuery()->fetch();
		if ($row) {
			return $this->mapRow($row);
		}

		// Base currency isn't known to this service, so fall back to the
		// user's most common account currency, or USD as a last resort.
		$currQb = $this->qb();
		$currQb->select('currency')->from('fintrack_accounts')
			   ->where($currQb->expr()->eq('user_id', $currQb->createNamedParameter($userId)))
			   ->setMaxResults(1);
		$currencyRow = $currQb->executeQuery()->fetch();
		$currency = $currencyRow['currency'] ?? 'USD';

		return $this->create($userId, [
			'name'        => self::INVESTMENT_GAINS_ACCOUNT_NAME,
			'type'        => 'revenue',
			'currency'    => $currency,
			'icon'        => '📊',
			'color'       => '#9b6cf0',
			'description' => 'Auto-created account that records profit or loss whenever an investment account is sold/settled.',
			'active'      => 1,
		]);
	}

	/**
	 * Computes everything needed to sell/settle an investment account —
	 * the profit/loss transaction payload and the gains account to post it
	 * to — without actually creating the transaction. (AccountService can't
	 * depend on TransactionService directly, since TransactionService itself
	 * depends on AccountService; the controller creates the transaction and
	 * then calls markInvestmentSettled() below.)
	 */
	public function computeInvestmentSale(string $userId, int $id, float $sellPrice, string $sellDate): array {
		$account = $this->find($userId, $id);
		if (!$account['isInvestment']) {
			throw new \InvalidArgumentException('This account is not an investment account.');
		}
		if (!$account['active']) {
			throw new \InvalidArgumentException('This investment account has already been settled.');
		}

		$purchasePrice = $account['purchasePrice'] ?? 0.0;
		$diff = $sellPrice - $purchasePrice;
		$isGain = $diff >= 0;

		$gainsAccount = $this->ensureInvestmentGainsAccount($userId);
		$this->categoryService->ensureCategory($userId, self::INVESTMENT_GAINS_CATEGORY_NAME, 'expense', '📊');

		$purchaseDateStr = $account['purchaseDate'] ? date('Y-m-d', $account['purchaseDate']) : 'unknown';
		$sellDateStr     = date('Y-m-d', strtotime($sellDate));

		$notes = sprintf(
			"Purchase price: %s\nPurchase date: %s\nSelling date: %s\nSelling price: %s",
			number_format($purchasePrice, 2),
			$purchaseDateStr,
			$sellDateStr,
			number_format($sellPrice, 2)
		);

		return [
			'account'      => $account,
			'sellDateStr'  => $sellDateStr,
			'transactionPayload' => [
				'type'        => $isGain ? 'income' : 'expense',
				'accountId'   => $gainsAccount['id'],
				'amount'      => abs($diff),
				'currency'    => $gainsAccount['currency'],
				'category'    => self::INVESTMENT_GAINS_CATEGORY_NAME,
				'description' => sprintf('%s from investment %s', $isGain ? 'Profit' : 'Loss', $account['name']),
				'tags'        => [$account['name']],
				'notes'       => $notes,
				'date'        => $sellDateStr,
			],
		];
	}

	/** Marks the investment account inactive and records the settlement details. */
	public function markInvestmentSettled(string $userId, int $id, string $sellDateStr, float $sellPrice): array {
		$this->assertOwner($userId, 'fintrack_accounts', $id);
		$qb = $this->qb();
		$qb->update('fintrack_accounts')
		   ->set('active',        $qb->createNamedParameter(0, IQueryBuilder::PARAM_INT))
		   ->set('settled_date',  $qb->createNamedParameter(strtotime($sellDateStr), IQueryBuilder::PARAM_INT))
		   ->set('settled_price', $qb->createNamedParameter($sellPrice))
		   ->where($qb->expr()->eq('id', $qb->createNamedParameter($id, IQueryBuilder::PARAM_INT)));
		$qb->executeStatement();
		return $this->find($userId, $id);
	}
}
