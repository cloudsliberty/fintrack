// FinTrack — Central Data Store
const DB_KEY = 'fintrack_v1';

// ── CSP-safe delegated event handling ──
// All HTML injected via innerHTML uses data-action / data-change / data-input / data-blur
// attributes instead of inline onclick/onchange handlers, so the app works under
// Nextcloud 32's strict CSP (no 'unsafe-inline' and no 'unsafe-eval').
//
// Action expressions have the form:  fnName(arg1, arg2)
// Multiple calls may be chained with semicolons: fn1();fn2(arg)
//
// Supported argument literals:
//   'string'  "string"  — string literals
//   null                — null
//   el.value            — the value property of the triggering element
//   el                  — the triggering element itself
//
// All callable functions must be exposed on window (which they already are,
// either as top-level declarations or explicit window.* assignments).
(function installDelegatedHandlers() {

  // Parse a single call expression like  fnName('id', el.value)
  // Returns { name, args } or null on parse failure.
  function parseCall(expr, el) {
    expr = expr.trim();
    var parenOpen = expr.indexOf('(');
    if (parenOpen === -1) return null;
    var name = expr.slice(0, parenOpen).trim();
    var argsStr = expr.slice(parenOpen + 1, expr.lastIndexOf(')')).trim();

    var args = [];
    if (argsStr.length > 0) {
      // Tokenise: split on commas that are not inside quotes.
      var tokens = [];
      var cur = '';
      var inQ = false, qChar = '';
      for (var i = 0; i < argsStr.length; i++) {
        var ch = argsStr[i];
        if (inQ) {
          cur += ch;
          if (ch === qChar) inQ = false;
        } else if (ch === "'" || ch === '"') {
          inQ = true; qChar = ch; cur += ch;
        } else if (ch === ',') {
          tokens.push(cur.trim()); cur = '';
        } else {
          cur += ch;
        }
      }
      if (cur.trim()) tokens.push(cur.trim());

      for (var t = 0; t < tokens.length; t++) {
        var tok = tokens[t];
        if (tok === 'null' || tok === 'undefined') {
          args.push(null);
        } else if (tok === 'el.value') {
          args.push(el ? el.value : undefined);
        } else if (tok === 'el') {
          args.push(el);
        } else if ((tok[0] === "'" && tok[tok.length-1] === "'") ||
                   (tok[0] === '"' && tok[tok.length-1] === '"')) {
          args.push(tok.slice(1, -1));
        } else if (tok === 'true') {
          args.push(true);
        } else if (tok === 'false') {
          args.push(false);
        } else if (!isNaN(tok)) {
          args.push(Number(tok));
        } else {
          // Unknown token — pass as string (shouldn't happen with current actions)
          args.push(tok);
        }
      }
    }
    return { name: name, args: args };
  }

  // Execute one or more semicolon-separated call expressions.
  function invokeExpr(expr, el) {
    // Split on ';' that are not inside parens or quotes.
    var calls = [];
    var cur = '', depth = 0, inQ = false, qChar = '';
    for (var i = 0; i < expr.length; i++) {
      var ch = expr[i];
      if (inQ) {
        cur += ch;
        if (ch === qChar) inQ = false;
      } else if (ch === "'" || ch === '"') {
        inQ = true; qChar = ch; cur += ch;
      } else if (ch === '(') {
        depth++; cur += ch;
      } else if (ch === ')') {
        depth--; cur += ch;
      } else if (ch === ';' && depth === 0) {
        if (cur.trim()) calls.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    if (cur.trim()) calls.push(cur.trim());

    for (var c = 0; c < calls.length; c++) {
      var parsed = parseCall(calls[c], el);
      if (!parsed) { console.error('FT: unparseable action:', calls[c]); continue; }
      var fn = window[parsed.name];
      if (typeof fn !== 'function') { console.error('FT: unknown action fn:', parsed.name); continue; }
      try { fn.apply(window, parsed.args); } catch (err) { console.error('FT: action error in', parsed.name, err); }
    }
  }

  function dispatch(attrName, e) {
    let el = e.target;
    while (el && el !== document.body) {
      if (el.classList.contains('ft-stop-propagation') && attrName === 'data-action') {
        const expr = el.getAttribute(attrName);
        if (!expr) { e.stopPropagation(); return; }
      }
      const expr = el.getAttribute(attrName);
      if (expr) {
        e.stopPropagation();
        invokeExpr(expr, el);
        return;
      }
      el = el.parentElement;
    }
  }

  document.addEventListener('click',  function(e) { dispatch('data-action', e); });
  document.addEventListener('change', function(e) { dispatch('data-change', e); });
  document.addEventListener('input',  function(e) { dispatch('data-input',  e); });
  document.addEventListener('blur',   function(e) { dispatch('data-blur',   e); }, true);
})();


const DEFAULT_DATA = {
  currencies: [
    { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1 },
    { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.92 },
    { code: 'GBP', name: 'British Pound', symbol: '£', rate: 0.79 },
    { code: 'SAR', name: 'Saudi Riyal', symbol: '﷼', rate: 3.75 },
    { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', rate: 3.67 },
  ],
  baseCurrency: 'USD',
  accounts: [
    { id: 'a1', name: 'Main Checking', type: 'asset', currency: 'USD', description: 'Primary bank account', color: '#4f8ef7', icon: '🏦', active: true, created: new Date().toISOString() },
    { id: 'a2', name: 'Savings', type: 'asset', currency: 'USD', description: 'Emergency fund', color: '#2ecc8a', icon: '💰', active: true, created: new Date().toISOString() },
    { id: 'a3', name: 'Groceries', type: 'expense', currency: 'USD', description: 'Weekly grocery spending', color: '#f05151', icon: '🛒', active: true, created: new Date().toISOString() },
    { id: 'a4', name: 'Utilities', type: 'expense', currency: 'USD', description: 'Monthly utilities', color: '#f0c040', icon: '⚡', active: true, created: new Date().toISOString() },
    { id: 'a5', name: 'Salary', type: 'revenue', currency: 'USD', description: 'Monthly salary', color: '#2ecc8a', icon: '💼', active: true, created: new Date().toISOString() },
    { id: 'a6', name: 'Credit Card', type: 'liability', currency: 'USD', description: 'Visa credit card', color: '#f0c040', icon: '💳', active: true, created: new Date().toISOString() },
  ],
  transactions: [
    { id: 't1', type: 'income', accountId: 'a1', amount: 5000, currency: 'USD', category: 'Salary', tags: ['monthly'], description: 'Monthly salary', date: new Date(Date.now() - 86400000 * 5).toISOString(), linkedAccountId: 'a5', created: new Date().toISOString() },
    { id: 't2', type: 'expense', accountId: 'a1', amount: 120, currency: 'USD', category: 'Groceries', tags: ['food', 'weekly'], description: 'Supermarket run', date: new Date(Date.now() - 86400000 * 3).toISOString(), linkedAccountId: 'a3', created: new Date().toISOString() },
    { id: 't3', type: 'expense', accountId: 'a1', amount: 85, currency: 'USD', category: 'Utilities', tags: ['bills'], description: 'Electricity bill', date: new Date(Date.now() - 86400000 * 2).toISOString(), linkedAccountId: 'a4', created: new Date().toISOString() },
    { id: 't4', type: 'income', accountId: 'a2', amount: 500, currency: 'USD', category: 'Transfer', tags: [], description: 'Transfer to savings', date: new Date(Date.now() - 86400000 * 1).toISOString(), linkedAccountId: null, created: new Date().toISOString() },
  ],
  transfers: [
    { id: 'tr1', fromAccountId: 'a1', toAccountId: 'a2', fromAmount: 500, toAmount: 500, fromCurrency: 'USD', toCurrency: 'USD', conversionRate: 1, description: 'Transfer to savings', date: new Date(Date.now() - 86400000).toISOString(), created: new Date().toISOString() },
  ],
  budgets: [
    { id: 'b1', name: 'Monthly Groceries', limit: 600, currency: 'USD', period: 'monthly', category: 'Groceries', accountIds: ['a3'], active: true, startDate: new Date().toISOString(), created: new Date().toISOString() },
    { id: 'b2', name: 'Utilities Budget', limit: 200, currency: 'USD', period: 'monthly', category: 'Utilities', accountIds: ['a4'], active: true, startDate: new Date().toISOString(), created: new Date().toISOString() },
  ],
  categories: [
    { id: 'c1', name: 'Salary', type: 'income', color: '#2ecc8a', icon: '💼' },
    { id: 'c2', name: 'Freelance', type: 'income', color: '#4f8ef7', icon: '💻' },
    { id: 'c3', name: 'Investment', type: 'income', color: '#9b6cf0', icon: '📈' },
    { id: 'c4', name: 'Groceries', type: 'expense', color: '#f05151', icon: '🛒' },
    { id: 'c5', name: 'Utilities', type: 'expense', color: '#f0c040', icon: '⚡' },
    { id: 'c6', name: 'Transport', type: 'expense', color: '#4f8ef7', icon: '🚗' },
    { id: 'c7', name: 'Dining', type: 'expense', color: '#f0c040', icon: '🍽️' },
    { id: 'c8', name: 'Health', type: 'expense', color: '#2ecc8a', icon: '🏥' },
    { id: 'c9', name: 'Entertainment', type: 'expense', color: '#9b6cf0', icon: '🎬' },
    { id: 'c10', name: 'Transfer', type: 'transfer', color: '#9aa3b8', icon: '↔️' },
  ],
  tags: ['monthly', 'food', 'weekly', 'bills', 'personal', 'work', 'annual', 'recurring'],
  apiKey: generateId('key'),
};

function generateId(prefix = 'id') {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// ── State ──
// In Nextcloud mode fintrack-main.js registers window.getState before this file
// runs (script load order: fintrack-main first, fintrack-core second).
// We never cache the state reference at module level — we always call
// window.getState() so that async updates from fintrack-main.js are reflected.
// Fallback: standalone / dev mode initialises from DEFAULT_DATA.
let _standaloneState = null;

function getState() {
  // In Nextcloud mode, fintrack-main.js registers window._ftGetState (not window.getState)
  // to avoid the infinite recursion that occurs when this function checks window.getState
  // and window.getState IS this function (standalone fallback path).
  if (typeof window._ftGetState === 'function') {
    return window._ftGetState();
  }
  // Standalone fallback
  if (!_standaloneState) {
    _standaloneState = JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
  return _standaloneState;
}

function loadState() {
  // Kept for compatibility; getState() is the canonical accessor now.
  return getState();
}

function saveState() {
  // In Nextcloud mode mutations go via the REST API (fintrack-main.js).
  // Use _ftSaveState (not window.saveState) to avoid calling ourselves
  // since this function is also exposed as window.saveState at global scope.
  if (typeof window._ftSaveState === 'function') window._ftSaveState();
}

// Expose getState globally so fintrack-main.js helpers can call it if needed.
// Note: do NOT assign window.getState = getState here — that would cause
// infinite recursion since getState() checks window._ftGetState, not window.getState.
if (typeof window.getState !== 'function') {
  window.getState = getState;
}

// ── Currency helpers ──
function getRate(fromCode, toCode) {
  if (fromCode === toCode) return 1;
  const s = getState();
  if (!s || !s.currencies) return 1;
  const from = s.currencies.find(c => c.code === fromCode);
  const to = s.currencies.find(c => c.code === toCode);
  if (!from || !to) return 1;
  // All rates are relative to baseCurrency (USD by default = rate 1)
  // from→USD: 1/from.rate; USD→to: to.rate
  return to.rate / from.rate;
}

function convertAmount(amount, fromCode, toCode) {
  return amount * getRate(fromCode, toCode);
}

// Convert a transaction's amount into the base currency for totals/reports.
//
// Transactions in a foreign currency store a snapshot of the conversion rate
// that applied when they were entered (tx.conversionRate). We must use that
// snapshot instead of the live currency table — otherwise editing a currency's
// rate today would silently re-price every past transaction in that currency.
// Only fall back to the live rate for older transactions that predate this
// feature and never got a rate recorded.
function transactionAmountInBase(t) {
  const s = getState();
  const base = s ? s.baseCurrency : 'USD';
  const amount = parseFloat(t.amount) || 0;
  if (!t.currency || t.currency === base) return amount;
  if (t.conversionRate) return amount * parseFloat(t.conversionRate);
  return convertAmount(amount, t.currency, base);
}

function formatCurrency(amount, currencyCode) {
  const s = getState();
  const cur = (s && s.currencies) ? s.currencies.find(c => c.code === currencyCode) : null;
  const symbol = cur ? cur.symbol : (currencyCode || '');
  const abs = Math.abs(amount);
  const formatted = abs.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${symbol}${formatted}`;
}

// ── Account helpers ──
function getAccountBalance(accountId) {
  const s = getState();
  if (!s) return 0;
  const acc = s.accounts.find(a => a.id == accountId);
  if (!acc) return 0;

  let balance = 0;
  (s.transactions || []).forEach(t => {
    if (t.accountId != accountId) return;
    if (t.type === 'income') balance += parseFloat(t.amount);
    else if (t.type === 'expense') balance -= parseFloat(t.amount);
  });

  // Transfers
  (s.transfers || []).forEach(tr => {
    if (tr.fromAccountId == accountId) balance -= parseFloat(tr.fromAmount);
    if (tr.toAccountId == accountId) balance += parseFloat(tr.toAmount);
  });

  return balance;
}

function getAccountIncome(accountId) {
  const s = getState();
  if (!s || !s.transactions) return 0;
  return s.transactions
    .filter(t => t.accountId == accountId && t.type == 'income')
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
}

function getAccountExpense(accountId) {
  const s = getState();
  if (!s || !s.transactions) return 0;
  return s.transactions
    .filter(t => t.accountId == accountId && t.type == 'expense')
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
}

function getTotalByType(type) {
  const s = getState();
  if (!s || !s.accounts) return 0;
  const accounts = s.accounts.filter(a => a.type === type);
  const base = s.baseCurrency;
  let total = 0;
  accounts.forEach(acc => {
    const bal = getAccountBalance(acc.id);
    total += convertAmount(bal, acc.currency, base);
  });
  return total;
}

function getCategorySpend(categoryName, period) {
  const s = getState();
  if (!s || !s.transactions) return 0;
  const now = new Date();
  let startDate;
  if (period === 'monthly') {
    startDate = new Date(now.getFullYear(), now.getMonth(), 1);
  } else if (period === 'weekly') {
    const d = now.getDay();
    startDate = new Date(now); startDate.setDate(now.getDate() - d);
  } else if (period === 'yearly') {
    startDate = new Date(now.getFullYear(), 0, 1);
  } else {
    startDate = new Date(0);
  }

  return s.transactions
    .filter(t => t.type === 'expense' && t.category === categoryName && new Date(t.date) >= startDate)
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
}

// FinTrack — Currencies Module

function renderCurrenciesPage() {
  const s = getState();
  const page = document.getElementById('page-currencies');

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Currencies</div>
        <div class="page-subtitle">Define currencies and set conversion rates relative to your base currency</div>
      </div>
      <button class="btn btn-primary" data-action="showAddCurrencyModal()">
        <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
        Add Currency
      </button>
    </div>

    <div class="content">
      <div class="card" style="margin-bottom:16px">
        <div class="card-header">
          <div class="card-title">Base Currency</div>
        </div>
        <div class="card-body">
          <p style="color:var(--text-2);font-size:13px;margin-bottom:12px">All balances will be converted to and displayed in the base currency for totals.</p>
          <div class="form-grid cols-3">
            <div class="form-group">
              <label>Base Currency</label>
              <select id="base-currency-select" data-change="setBaseCurrency(el.value)">
                ${s.currencies.map(c => `<option value="${c.code}" ${c.code === s.baseCurrency ? 'selected' : ''}>${c.code} — ${c.name}</option>`).join('')}
              </select>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="card-title">Currency Rates</div>
          <span style="font-size:12px;color:var(--text-3)">Rates relative to ${s.baseCurrency} (1 ${s.baseCurrency} = X currency)</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Symbol</th>
                <th>Rate (per ${s.baseCurrency})</th>
                <th>1 ${s.baseCurrency} =</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${s.currencies.map(c => `
                <tr>
                  <td><span class="chip accent">${c.code}</span></td>
                  <td>${c.name}</td>
                  <td class="td-mono">${c.symbol}</td>
                  <td>
                    ${c.code === s.baseCurrency
                      ? '<span class="td-muted">Base (1.00)</span>'
                      : `<div style="display:flex;gap:6px;align-items:center">
                           <input id="curr-rate-${c.code}" type="number" step="0.0001" value="${c.rate}" style="max-width:110px"
                             data-change="updateCurrencyRate('${c.code}', el.value)"
                             data-blur="updateCurrencyRate('${c.code}', el.value)">
                           <button type="button" class="btn btn-secondary btn-sm" title="Fetch the current rate online"
                             data-action="fetchOnlineRate('${s.baseCurrency}','${c.code}','curr-rate-${c.code}',el,'updateCurrencyRate')">⟳</button>
                         </div>`
                    }
                  </td>
                  <td class="td-mono">${c.symbol}${c.rate.toFixed(4)}</td>
                  <td>
                    ${c.code !== s.baseCurrency ? `
                      <button class="btn btn-danger btn-sm" data-action="deleteCurrency('${c.code}')">Remove</button>
                    ` : '<span class="chip">Base</span>'}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <div class="card" style="margin-top:16px">
        <div class="card-header"><div class="card-title">Conversion Calculator</div></div>
        <div class="card-body">
          <div class="form-grid cols-3">
            <div class="form-group">
              <label>Amount</label>
              <input type="number" id="calc-amount" value="100" data-input="updateCalc()">
            </div>
            <div class="form-group">
              <label>From</label>
              <select id="calc-from" data-change="updateCalc()">
                ${s.currencies.map(c => `<option value="${c.code}">${c.code}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label>To</label>
              <select id="calc-to" data-change="updateCalc()">
                ${s.currencies.map(c => `<option value="${c.code}" ${c.code !== s.baseCurrency ? 'selected' : ''}>${c.code}</option>`).join('')}
              </select>
            </div>
          </div>
          <div id="calc-result" class="conversion-info" style="margin-top:14px"></div>
        </div>
      </div>
    </div>
  `;

  updateCalc();
}

function updateCalc() {
  const amount = parseFloat(document.getElementById('calc-amount')?.value || 100);
  const from = document.getElementById('calc-from')?.value;
  const to = document.getElementById('calc-to')?.value;
  if (!from || !to) return;
  const result = convertAmount(amount, from, to);
  const s = getState();
  const fromCur = s.currencies.find(c => c.code === from);
  const toCur = s.currencies.find(c => c.code === to);
  document.getElementById('calc-result').innerHTML =
    `${fromCur.symbol}${amount.toLocaleString()} ${from} = <strong>${toCur.symbol}${result.toFixed(4)} ${to}</strong>
     &nbsp;·&nbsp; Rate: 1 ${from} = ${getRate(from, to).toFixed(6)} ${to}`;
}

function setBaseCurrency(code) {
  if (typeof window._ftSetBaseCurrency === 'function') { window._ftSetBaseCurrency(code); return; }
  const state = getState();
  state.baseCurrency = code;
  saveState();
  showToast('Base currency updated', 'success');
  renderCurrenciesPage();
}

function updateCurrencyRate(code, value) {
  if (typeof window._ftUpdateCurrencyRate === 'function') { window._ftUpdateCurrencyRate(code, value); return; }
  const state = getState();
  const rate = parseFloat(value);
  if (isNaN(rate) || rate <= 0) return;
  const cur = state.currencies.find(c => c.code === code);
  if (cur) { cur.rate = rate; saveState(); }
  updateCalc();
}

function deleteCurrency(code) {
  if (typeof window._ftDeleteCurrency === 'function') { window._ftDeleteCurrency(code); return; }
  const state = getState();
  const inUse = state.accounts.some(a => a.currency === code);
  if (inUse) { showToast('Cannot remove currency in use by accounts', 'error'); return; }
  state.currencies = state.currencies.filter(c => c.code !== code);
  saveState();
  showToast('Currency removed', 'success');
  renderCurrenciesPage();
}

function showAddCurrencyModal() {
  openModal('Add Currency', `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group">
          <label>Currency Code *</label>
          <input id="cur-code" placeholder="e.g. JPY" maxlength="3" style="text-transform:uppercase">
        </div>
        <div class="form-group">
          <label>Symbol *</label>
          <input id="cur-symbol" placeholder="e.g. ¥">
        </div>
        <div class="form-group full">
          <label>Name *</label>
          <input id="cur-name" placeholder="e.g. Japanese Yen">
        </div>
        <div class="form-group">
          <label>Rate (1 ${getState().baseCurrency} = X) *</label>
          <input id="cur-rate" type="number" step="0.0001" placeholder="e.g. 150.0">
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-primary" data-action="saveCurrency()">Add Currency</button>
      </div>
    </div>
  `);
}

function saveCurrency() {
  // In Nextcloud mode, delegate to the API-backed version registered by fintrack-main.js.
  if (typeof window._ftSaveCurrency === 'function') { window._ftSaveCurrency(); return; }

  // Standalone fallback (no Nextcloud API available).
  const state = getState();
  const code = document.getElementById('cur-code').value.trim().toUpperCase();
  const name = document.getElementById('cur-name').value.trim();
  const symbol = document.getElementById('cur-symbol').value.trim();
  const rate = parseFloat(document.getElementById('cur-rate').value);

  if (!code || !name || !symbol || isNaN(rate)) { showToast('Please fill all fields', 'error'); return; }
  if (state.currencies.find(c => c.code === code)) { showToast('Currency code already exists', 'error'); return; }

  state.currencies.push({ code, name, symbol, rate });
  saveState();
  showToast('Currency added', 'success');
  closeModal();
  renderCurrenciesPage();
}
// FinTrack — Accounts Module

const ACCOUNT_TYPES = {
  asset: { label: 'Asset', color: 'accent', desc: 'Bank accounts, cash, investments' },
  expense: { label: 'Expense', color: 'red', desc: 'Spending categories' },
  revenue: { label: 'Revenue', color: 'green', desc: 'Income sources' },
  liability: { label: 'Liability', color: 'yellow', desc: 'Loans, credit cards, debts' },
};

// Per-type UI state for the Accounts pages (compact toggle + section
// expand/collapse). Kept in memory only — resets on reload, which is fine
// since it's a display preference, not data.
window._ftAccountsView = window._ftAccountsView || {};
function getAccountsViewState(type) {
  if (!window._ftAccountsView[type]) {
    window._ftAccountsView[type] = { compact: false, expandActive: true, expandInactive: false };
  }
  return window._ftAccountsView[type];
}
function toggleAccountsCompact(type) {
  const v = getAccountsViewState(type);
  v.compact = !v.compact;
  renderAccountsPage(type);
}
function toggleAccountsSection(type, section) {
  const v = getAccountsViewState(type);
  const key = 'expand' + section;
  v[key] = !v[key];
  renderAccountsPage(type);
}

function renderAccountsPage(type) {
  const s = getState();
  const cfg = ACCOUNT_TYPES[type];
  const accounts = s.accounts.filter(a => a.type === type);
  const page = document.getElementById(`page-${type}-accounts`);
  const view = getAccountsViewState(type);

  // Totals
  let totalIncome = 0, totalExpense = 0, totalBalance = 0;
  accounts.forEach(acc => {
    const bal = getAccountBalance(acc.id);
    const inc = getAccountIncome(acc.id);
    const exp = getAccountExpense(acc.id);
    totalBalance += convertAmount(bal, acc.currency, s.baseCurrency);
    totalIncome += convertAmount(inc, acc.currency, s.baseCurrency);
    totalExpense += convertAmount(exp, acc.currency, s.baseCurrency);
  });

  const baseCur = s.currencies.find(c => c.code === s.baseCurrency);
  const activeAccounts = accounts.filter(a => a.active);
  const inactiveAccounts = accounts.filter(a => !a.active);

  function section(label, list, key) {
    const expanded = view['expand' + key];
    if (accounts.length === 0) return '';
    return `
      <div class="accounts-section">
        <div class="accounts-section-header" data-action="toggleAccountsSection('${type}','${key}')">
          <svg class="accounts-section-chevron ${expanded ? 'expanded' : ''}" viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>
          <span class="accounts-section-title">${label}</span>
          <span class="chip">${list.length}</span>
        </div>
        ${expanded ? (list.length === 0
          ? `<div class="ft-empty-inline">No ${label.toLowerCase()} accounts</div>`
          : `<div class="accounts-grid ${view.compact ? 'compact' : ''}">${list.map(acc => renderAccountCard(acc, view.compact)).join('')}</div>`
        ) : ''}
      </div>
    `;
  }

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">${cfg.label} Accounts</div>
        <div class="page-subtitle">${cfg.desc}</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary" title="${view.compact ? 'Switch to normal view' : 'Switch to compact view'}" data-action="toggleAccountsCompact('${type}')">
          <svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor">${view.compact
            ? '<path d="M4 4h16v4H4zm0 6h16v4H4zm0 6h16v4H4z"/>'
            : '<path d="M4 4h7v7H4zm9 0h7v7h-7zM4 13h7v7H4zm9 0h7v7h-7z"/>'}</svg>
          ${view.compact ? 'Normal View' : 'Compact View'}
        </button>
        <button class="btn btn-primary" data-action="showAccountModal(null,'${type}')">
          <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
          New Account
        </button>
      </div>
    </div>

    <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-label">Total Balance</div>
        <div class="stat-value accent">${formatCurrency(totalBalance, s.baseCurrency)}</div>
        <div class="stat-sub">All ${cfg.label} accounts in ${s.baseCurrency}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Income</div>
        <div class="stat-value green">${formatCurrency(totalIncome, s.baseCurrency)}</div>
        <div class="stat-sub">Across all ${cfg.label} accounts</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Expenses</div>
        <div class="stat-value red">${formatCurrency(totalExpense, s.baseCurrency)}</div>
        <div class="stat-sub">Across all ${cfg.label} accounts</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Accounts</div>
        <div class="stat-value">${accounts.length}</div>
        <div class="stat-sub">${activeAccounts.length} active</div>
      </div>
    </div>

    <div class="content">
      ${accounts.length === 0 ? `
        <div class="empty-state">
          <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l7.59-7.59L21 8l-9 9z"/></svg>
          <div class="empty-title">No ${cfg.label} accounts yet</div>
          <p>Create your first ${cfg.label.toLowerCase()} account to start tracking your finances.</p>
          <br>
          <button class="btn btn-primary" data-action="showAccountModal(null,'${type}')">Create Account</button>
        </div>
      ` : `
        ${section('Active', activeAccounts, 'Active')}
        ${section('Inactive', inactiveAccounts, 'Inactive')}
      `}
    </div>
  `;
}

function renderAccountCard(acc, compact) {
  const bal = getAccountBalance(acc.id);
  const inc = getAccountIncome(acc.id);
  const exp = getAccountExpense(acc.id);

  const accColor = acc.color || '#4f8ef7';
  const typeLabel = ACCOUNT_TYPES[acc.type]?.label || acc.type;

  if (compact) {
    return `
      <div class="account-card compact type-${acc.type}" style="border-left: 7px solid ${accColor}" data-action="showAccountTransactions('${acc.id}')">
        <div class="account-card-name" style="color:${accColor}"><span class="account-card-icon">${acc.icon || ''}</span> ${acc.name}</div>
        <div class="account-card-typeline">(${typeLabel})</div>
        <div class="account-balance compact">${formatCurrency(bal, acc.currency)}</div>
        <div class="account-actions ft-stop-propagation">
          <button class="btn btn-ghost btn-icon btn-sm" title="Edit" data-action="showAccountModal('${acc.id}')">
            <svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
          </button>
        </div>
        ${!acc.active ? '<span class="account-badge">Inactive</span>' : ''}
      </div>
    `;
  }

  return `
    <div class="account-card type-${acc.type}" style="border-left: 7px solid ${accColor}" data-action="showAccountTransactions('${acc.id}')">
      <div class="account-card-name" style="color:${accColor}"><span class="account-card-icon">${acc.icon || ''}</span> ${acc.name}${acc.isInvestment ? ' <span class="chip" style="font-size:9px;vertical-align:middle">INVESTMENT</span>' : ''}</div>
      <div class="account-card-typeline">(${typeLabel})</div>
      <div class="account-card-currency">${acc.currency}</div>
      <div class="account-balance">${formatCurrency(bal, acc.currency)}</div>
      <div class="account-income-expense">
        <div class="account-inc">▲ ${formatCurrency(inc, acc.currency)}</div>
        <div class="account-exp">▼ ${formatCurrency(exp, acc.currency)}</div>
      </div>
      <div class="account-actions ft-stop-propagation">
        <button class="btn btn-ghost btn-icon btn-sm" title="Edit" data-action="showAccountModal('${acc.id}')">
          <svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
        </button>
        <button class="btn btn-danger btn-icon btn-sm" title="Delete" data-action="deleteAccount('${acc.id}')">
          <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
        </button>
      </div>
      ${!acc.active ? '<span class="account-badge">Inactive</span>' : ''}
    </div>
  `;
}

// ══════════════════════════════════════════════
//  EMOJI / ICON PICKER (inline popover, not a modal)
// ══════════════════════════════════════════════
// A second openModal() call would blow away whatever form is already open
// (there's only one modal container), so this renders as a small popover
// panel inside the account form instead.
const FT_EMOJI_LIST = [
  { e: '🏦', n: 'bank' }, { e: '💰', n: 'money bag savings' }, { e: '💵', n: 'dollar banknote cash' },
  { e: '💳', n: 'credit card' }, { e: '🏧', n: 'atm' }, { e: '💴', n: 'yen banknote' },
  { e: '💶', n: 'euro banknote' }, { e: '💷', n: 'pound banknote' }, { e: '🪙', n: 'coin' },
  { e: '📈', n: 'chart increasing profit investment' }, { e: '📉', n: 'chart decreasing loss' },
  { e: '💹', n: 'chart yen growth' }, { e: '🏠', n: 'house home' }, { e: '🏡', n: 'house garden home' },
  { e: '🚗', n: 'car vehicle transport' }, { e: '✈️', n: 'airplane travel' },
  { e: '🛒', n: 'cart shopping groceries' }, { e: '🍔', n: 'burger food dining' }, { e: '☕', n: 'coffee' },
  { e: '🎓', n: 'graduation education school' }, { e: '💊', n: 'medicine health' }, { e: '🏥', n: 'hospital health' },
  { e: '🎬', n: 'movie entertainment' }, { e: '🎮', n: 'game entertainment' }, { e: '📱', n: 'phone mobile bill' },
  { e: '💻', n: 'laptop computer' }, { e: '🎁', n: 'gift' }, { e: '🧾', n: 'receipt bill invoice' },
  { e: '🪪', n: 'card id' }, { e: '💎', n: 'diamond gem investment' }, { e: '🥇', n: 'gold medal investment' },
  { e: '🛢️', n: 'oil barrel commodity investment' }, { e: '🏗️', n: 'construction real estate investment' },
  { e: '📊', n: 'bar chart stats' }, { e: '🐖', n: 'piggy pig savings' }, { e: '👛', n: 'purse wallet' },
  { e: '⚡', n: 'utility electricity bill' }, { e: '💡', n: 'idea utility bill' }, { e: '🚰', n: 'water utility bill' },
  { e: '📶', n: 'internet wifi bill' }, { e: '🏋️', n: 'gym fitness health' }, { e: '🍽️', n: 'restaurant dining' },
  { e: '🎉', n: 'party celebration' }, { e: '🐾', n: 'pet animal' }, { e: '🧳', n: 'travel luggage' },
  { e: '📚', n: 'books education' }, { e: '🛠️', n: 'tools maintenance' }, { e: '🧢', n: 'clothing apparel' },
  { e: '👶', n: 'baby childcare' }, { e: '🚕', n: 'taxi transport' }, { e: '🚌', n: 'bus transport' },
  { e: '💼', n: 'briefcase business salary' }, { e: '🏢', n: 'office building business' },
];

function toggleEmojiPicker(pickerId, inputId) {
  const panel = document.getElementById(pickerId);
  if (!panel) return;
  const showing = panel.style.display !== 'none';
  panel.style.display = showing ? 'none' : 'block';
  if (!showing) renderEmojiGrid(inputId, pickerId, '');
}

function renderEmojiGrid(inputId, pickerId, query) {
  const grid = document.getElementById(pickerId + '-grid');
  if (!grid) return;
  const q = (query || '').toLowerCase();
  const filtered = FT_EMOJI_LIST.filter(x => !q || x.n.includes(q));
  grid.innerHTML = filtered.length
    ? filtered.map(x => `<button type="button" class="ft-emoji-opt" title="${x.n}" data-action="pickEmoji('${inputId}','${pickerId}','${x.e}')">${x.e}</button>`).join('')
    : `<div class="ft-combo-empty">No icons found</div>`;
}

function filterEmojiGrid(inputId, pickerId) {
  const search = document.getElementById(pickerId + '-search');
  renderEmojiGrid(inputId, pickerId, search ? search.value : '');
}

function pickEmoji(inputId, pickerId, emoji) {
  const input = document.getElementById(inputId);
  if (input) input.value = emoji;
  const panel = document.getElementById(pickerId);
  if (panel) panel.style.display = 'none';
}

function emojiPickerFieldHTML(inputId, value) {
  const pickerId = inputId + '-picker';
  return `
    <div style="display:flex;align-items:center;gap:8px">
      <input id="${inputId}" value="${value || ''}" maxlength="4" class="ft-emoji-input" readonly>
      <button type="button" class="btn btn-secondary btn-sm" data-action="toggleEmojiPicker('${pickerId}','${inputId}')">Choose icon…</button>
    </div>
    <div id="${pickerId}" class="ft-emoji-popover" style="display:none">
      <input id="${pickerId}-search" placeholder="Search icons…" autocomplete="off" data-input="filterEmojiGrid('${inputId}','${pickerId}')">
      <div class="ft-emoji-grid" id="${pickerId}-grid"></div>
    </div>
  `;
}

function showAccountModal(accountId, defaultType) {
  const s = getState();
  const acc = accountId ? s.accounts.find(a => a.id == accountId) : null;
  const title = acc ? 'Edit Account' : 'New Account';
  const accType = acc?.type || defaultType || 'asset';
  const isInvestment = !!acc?.isInvestment;

  openModal(title, `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group full">
          <label>Account Name *</label>
          <input id="acc-name" placeholder="e.g. Main Checking" value="${acc?.name || ''}">
        </div>
        <div class="form-group">
          <label>Type *</label>
          <select id="acc-type" data-change="toggleInvestmentSection()">
            ${Object.entries(ACCOUNT_TYPES).map(([v, cfg]) =>
              `<option value="${v}" ${accType === v ? 'selected' : ''}>${cfg.label}</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Currency *</label>
          <select id="acc-currency">
            ${s.currencies.map(c => `<option value="${c.code}" ${(acc?.currency || s.baseCurrency) === c.code ? 'selected' : ''}>${c.code} — ${c.name}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Icon (emoji)</label>
          ${emojiPickerFieldHTML('acc-icon', acc?.icon || '')}
        </div>
        <div class="form-group">
          <label>Color</label>
          <input id="acc-color" type="color" value="${acc?.color || '#4f8ef7'}">
        </div>
        <div class="form-group full">
          <label>Description</label>
          <textarea id="acc-desc" placeholder="Optional description...">${acc?.description || ''}</textarea>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select id="acc-active" ${isInvestment && acc && !acc.active ? 'disabled' : ''}>
            <option value="true" ${!acc || acc.active ? 'selected' : ''}>Active</option>
            <option value="false" ${acc && !acc.active ? 'selected' : ''}>Inactive</option>
          </select>
        </div>

        <div class="form-group full" id="acc-investment-section" style="display:${accType === 'asset' ? '' : 'none'}">
          <label style="display:flex;align-items:center;gap:8px;font-weight:600">
            <input type="checkbox" id="acc-is-investment" style="width:auto" ${isInvestment ? 'checked' : ''} data-change="toggleInvestmentFields()">
            This is an investment (gold, stocks, crypto, mutual funds, real estate…)
          </label>
          <div id="acc-investment-fields" style="display:${isInvestment ? '' : 'none'};margin-top:10px">
            <div class="form-grid">
              <div class="form-group">
                <label>Purchase Price</label>
                <input id="acc-purchase-price" type="number" step="0.01" placeholder="0.00" value="${acc?.purchasePrice ?? ''}">
              </div>
              <div class="form-group">
                <label>Purchase Date</label>
                <input id="acc-purchase-date" type="date" value="${acc?.purchaseDate ? new Date(acc.purchaseDate * 1000).toISOString().split('T')[0] : ''}">
              </div>
            </div>
            <p style="font-size:12px;color:var(--text-3);margin-top:6px">
              When you sell or settle this investment, use the "Sell / Settle" button below — the profit or loss is
              automatically recorded on the default <strong>Investment Gains / Losses</strong> account.
            </p>
          </div>
        </div>
      </div>
      <div class="form-actions" style="justify-content:${(acc && isInvestment && acc.active) ? 'space-between' : 'flex-end'}">
        ${(acc && isInvestment && acc.active) ? `
          <button class="btn btn-danger" data-action="showSellInvestmentModal('${accountId}')">Sell / Settle Investment</button>
        ` : ''}
        <div style="display:flex;gap:10px">
          <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
          <button class="btn btn-primary" data-action="saveAccount('${accountId || ''}')">
            ${acc ? 'Save Changes' : 'Create Account'}
          </button>
        </div>
      </div>
    </div>
  `);
}

// Shows/hides the "is this an investment?" checkbox depending on whether
// Asset is the selected account type (investments only make sense as assets).
function toggleInvestmentSection() {
  const typeSel = document.getElementById('acc-type');
  const section = document.getElementById('acc-investment-section');
  if (!typeSel || !section) return;
  section.style.display = typeSel.value === 'asset' ? '' : 'none';
  if (typeSel.value !== 'asset') {
    const cb = document.getElementById('acc-is-investment');
    if (cb) cb.checked = false;
    toggleInvestmentFields();
  }
}

function toggleInvestmentFields() {
  const cb = document.getElementById('acc-is-investment');
  const fields = document.getElementById('acc-investment-fields');
  if (!cb || !fields) return;
  fields.style.display = cb.checked ? '' : 'none';
}

// Sell/Settle modal — mirrors the account modal's constraints (single modal
// container), so this replaces the currently-open account form rather than
// stacking on top of it. Cancelling returns to the account edit form.
function showSellInvestmentModal(accountId) {
  const s = getState();
  const acc = s.accounts.find(a => a.id == accountId);
  if (!acc) return;
  const purchasePrice = acc.purchasePrice ?? 0;

  openModal(`Sell / Settle: ${acc.name}`, `
    <div class="form-grid cols-1">
      <div class="ft-empty-inline" style="padding:0 0 12px">
        Purchase price was <strong>${formatCurrency(purchasePrice, acc.currency)}</strong>${acc.purchaseDate ? ` on ${new Date(acc.purchaseDate * 1000).toLocaleDateString()}` : ''}.
        This account will be marked inactive, and the profit or loss will be recorded on
        <strong>Investment Gains / Losses</strong>.
      </div>
      <div class="form-grid">
        <div class="form-group">
          <label>Selling Price *</label>
          <input id="sell-price" type="number" step="0.01" placeholder="0.00">
        </div>
        <div class="form-group">
          <label>Selling Date *</label>
          <input id="sell-date" type="date" value="${new Date().toISOString().split('T')[0]}">
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="showAccountModal('${accountId}')">Back</button>
        <button class="btn btn-primary" data-action="confirmSellInvestment('${accountId}')">Confirm Sale</button>
      </div>
    </div>
  `);
}

async function confirmSellInvestment(accountId) {
  const sellPrice = parseFloat(document.getElementById('sell-price').value);
  const sellDate = document.getElementById('sell-date').value;
  if (!sellPrice || sellPrice <= 0) { showToast('Enter a valid selling price', 'error'); return; }
  if (!sellDate) { showToast('Enter a selling date', 'error'); return; }
  if (typeof window._ftSellInvestment === 'function') {
    await window._ftSellInvestment(accountId, sellPrice, sellDate);
  }
}

function saveAccount(accountId) {
  if (typeof window._ftSaveAccount === 'function') { window._ftSaveAccount(accountId); return; }
  const state = getState();
  const name = document.getElementById('acc-name').value.trim();
  if (!name) { showToast('Account name required', 'error'); return; }

  const data = {
    name,
    type: document.getElementById('acc-type').value,
    currency: document.getElementById('acc-currency').value,
    icon: document.getElementById('acc-icon').value.trim(),
    color: document.getElementById('acc-color').value,
    description: document.getElementById('acc-desc').value.trim(),
    active: document.getElementById('acc-active').value === 'true',
  };

  if (accountId) {
    const acc = state.accounts.find(a => a.id == accountId);
    if (acc) Object.assign(acc, data);
    showToast('Account updated', 'success');
  } else {
    state.accounts.push({ id: generateId('acc'), ...data, created: new Date().toISOString() });
    showToast('Account created', 'success');
  }

  saveState();
  closeModal();
  refreshCurrentPage();
}

function deleteAccount(accountId) {
  if (typeof window._ftDeleteAccount === 'function') { window._ftDeleteAccount(accountId); return; }
  const state = getState();
  const inUse = state.transactions.some(t => t.accountId == accountId) ||
                state.transfers.some(t => t.fromAccountId == accountId || t.toAccountId == accountId);
  if (inUse) { showToast('Cannot delete account with transactions', 'error'); return; }

  state.accounts = state.accounts.filter(a => a.id !== accountId);
  saveState();
  showToast('Account deleted', 'success');
  refreshCurrentPage();
}

// Clicking an account tile jumps to the All Transactions page, pre-filtered
// to that account, so the user can see every transaction for it across all dates.
function showAccountTransactions(accountId) {
  const s = getState();
  const acc = s.accounts.find(a => a.id == accountId);
  if (!acc) return;

  navigate('transactions');

  const sel = document.getElementById('tx-account-filter');
  if (sel) {
    sel.value = String(accountId);
    filterTransactions();
  }
}
// FinTrack — Transactions Module

function renderTransactionsPage() {
  const s = getState();
  const page = document.getElementById('page-transactions');

  const sorted = [...s.transactions].sort((a, b) => new Date(b.date) - new Date(a.date));

  // The "date from" / "date until" filters are persisted in settings so they are
  // always restored to whatever the user last set, every time this page loads.
  const savedFrom = s.settings?.tx_filter_from || '';
  const savedTo = s.settings?.tx_filter_to || '';

  // Compute the initial list directly from the saved dates rather than reading
  // the filter inputs from the DOM, since those don't exist yet on first render.
  let initialList = sorted;
  if (savedFrom) initialList = initialList.filter(t => new Date(t.date) >= new Date(savedFrom));
  if (savedTo) initialList = initialList.filter(t => new Date(t.date) <= new Date(savedTo + 'T23:59:59'));

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">All Transactions</div>
        <div class="page-subtitle">${sorted.length} transactions</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary" data-action="exportTransactionsCSV()">Export CSV</button>
        <button class="btn btn-secondary" data-action="showImportCsvModal()">Import CSV</button>
        <button class="btn btn-primary" data-action="openNewTransactionFromList()">
          <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
          New Transaction
        </button>
      </div>
    </div>

    <div class="filters-bar">
      <input type="text" id="tx-search" placeholder="Search..." data-input="filterTransactions()" style="flex:1;min-width:150px">
      <select id="tx-type-filter" data-change="filterTransactions()">
        <option value="">All Types</option>
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>
      <select id="tx-account-filter" data-change="filterTransactions()">
        <option value="">All Accounts</option>
        ${s.accounts.map(a => `<option value="${a.id}">${a.name}</option>`).join('')}
      </select>
      <select id="tx-category-filter" data-change="filterTransactions()">
        <option value="">All Categories</option>
        ${[...new Set(s.transactions.map(t => t.category).filter(Boolean))].map(c => `<option value="${c}">${c}</option>`).join('')}
      </select>
      <select id="tx-tag-filter" data-change="filterTransactions()">
        <option value="">All Tags</option>
        ${[...new Set(s.transactions.flatMap(t => t.tags || []))].sort().map(tg => `<option value="${tg}">${tg}</option>`).join('')}
      </select>
      <input type="date" id="tx-from-filter" value="${savedFrom}" data-change="filterTransactions()">
      <input type="date" id="tx-to-filter" value="${savedTo}" data-change="filterTransactions()">
      ${(savedFrom || savedTo) ? `<button class="btn btn-ghost btn-sm" data-action="clearTxDateFilter()" title="Clear saved date range">Clear dates</button>` : ''}
    </div>

    <div class="content" style="padding-top:16px">
      <div class="card">
        <div id="tx-summary-wrap">
          ${renderTransactionSummary(initialList)}
        </div>
        <div class="table-wrap" id="tx-table-wrap">
          ${renderTransactionTable(initialList)}
        </div>
      </div>
    </div>
  `;
}

// Renders a total both in the transactions' own (original) currency and, in
// brackets, converted to the base currency — unless the filtered set mixes
// several currencies, in which case only the base-currency total makes sense.
function formatSumWithBase(txList, nativeSum, baseSum, base) {
  const currencies = [...new Set(txList.map(t => t.currency))];
  if (currencies.length === 1 && currencies[0] === base) {
    return formatCurrency(baseSum, base);
  }
  if (currencies.length === 1) {
    return `${formatCurrency(nativeSum, currencies[0])} <span style="color:var(--text-3);font-weight:500">(${formatCurrency(baseSum, base)})</span>`;
  }
  return `${formatCurrency(baseSum, base)} <span style="color:var(--text-3);font-weight:500;font-size:11px">(mixed currencies)</span>`;
}

function renderTransactionSummary(transactions) {
  const s = getState();
  const base = s.baseCurrency;

  const incomeTx = transactions.filter(t => t.type === 'income');
  const expenseTx = transactions.filter(t => t.type === 'expense');

  const nativeIncome = incomeTx.reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
  const nativeExpense = expenseTx.reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

  const totalIncome = incomeTx.reduce((sum, t) => sum + transactionAmountInBase(t), 0);
  const totalExpense = expenseTx.reduce((sum, t) => sum + transactionAmountInBase(t), 0);

  const diff = totalIncome - totalExpense;

  return `
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;padding:14px 16px;border-bottom:1px solid var(--border)">
      <div style="background:var(--bg);border-radius:6px;padding:12px 14px">
        <div style="font-size:11.5px;color:var(--text-3);margin-bottom:4px">Total Income</div>
        <div class="td-mono td-green" style="font-size:18px;font-weight:700">${formatSumWithBase(incomeTx, nativeIncome, totalIncome, base)}</div>
      </div>
      <div style="background:var(--bg);border-radius:6px;padding:12px 14px">
        <div style="font-size:11.5px;color:var(--text-3);margin-bottom:4px">Total Expense</div>
        <div class="td-mono td-red" style="font-size:18px;font-weight:700">${formatSumWithBase(expenseTx, nativeExpense, totalExpense, base)}</div>
      </div>
      <div style="background:var(--bg);border-radius:6px;padding:12px 14px">
        <div style="font-size:11.5px;color:var(--text-3);margin-bottom:4px">Difference (Income − Expense)</div>
        <div class="td-mono ${diff >= 0 ? 'td-green' : 'td-red'}" style="font-size:18px;font-weight:700">${formatCurrency(diff, base)}</div>
      </div>
    </div>
  `;
}

function renderTransactionTable(transactions) {
  const s = getState();
  if (transactions.length === 0) {
    return `<div class="empty-state"><svg viewBox="0 0 24 24"><path d="M7 16l-4-4 4-4v3h8.25C16.24 11 18 12.76 18 14.75S16.24 18.5 14.25 18.5H10v-2h4.25c.96 0 1.75-.79 1.75-1.75S15.21 13 14.25 13H7v3z"/></svg><div class="empty-title">No transactions found</div><p>Add your first transaction or adjust your filters.</p></div>`;
  }

  return `
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Account</th>
          <th>Description</th>
          <th>Category</th>
          <th>Tags</th>
          <th>Type</th>
          <th>Amount</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        ${transactions.map(t => {
          const acc = s.accounts.find(a => a.id == t.accountId);
          return `
            <tr class="ft-row-clickable" data-action="showTransactionModal('${t.id}', null, true)" title="Click to view details">
              <td class="td-muted">${new Date(t.date).toLocaleDateString()}</td>
              <td>${acc ? `<span class="chip">${acc.icon || ''} ${acc.name}</span>` : '—'}</td>
              <td>${t.description || '—'}</td>
              <td>${t.category ? `<span class="chip">${t.category}</span>` : '—'}</td>
              <td>${(t.tags || []).map(tag => `<span class="chip">${tag}</span>`).join(' ')}</td>
              <td><span class="chip ${t.type === 'income' ? 'green' : 'red'}">${t.type}</span></td>
              <td class="td-mono ${t.type === 'income' ? 'td-green' : 'td-red'}">
                ${t.type === 'income' ? '+' : '-'}${formatCurrency(t.amount, t.currency)}
              </td>
              <td>
                <div class="ft-stop-propagation" style="display:flex;gap:4px">
                  <button class="btn btn-ghost btn-icon btn-sm" data-action="showTransactionModal('${t.id}')" title="Edit">
                    <svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>
                  </button>
                  <button class="btn btn-danger btn-icon btn-sm" data-action="deleteTransaction('${t.id}')" title="Delete">
                    <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12z"/></svg>
                  </button>
                </div>
              </td>
            </tr>
          `;
        }).join('')}
      </tbody>
    </table>
  `;
}

function getFilteredTransactions() {
  const s = getState();
  const search = (document.getElementById('tx-search')?.value || '').toLowerCase();
  const type = document.getElementById('tx-type-filter')?.value || '';
  const account = document.getElementById('tx-account-filter')?.value || '';
  const category = document.getElementById('tx-category-filter')?.value || '';
  const tag = document.getElementById('tx-tag-filter')?.value || '';
  const from = document.getElementById('tx-from-filter')?.value;
  const to = document.getElementById('tx-to-filter')?.value;

  let filtered = [...s.transactions].sort((a, b) => new Date(b.date) - new Date(a.date));

  if (search) filtered = filtered.filter(t =>
    (t.description || '').toLowerCase().includes(search) ||
    (t.category || '').toLowerCase().includes(search) ||
    (t.tags || []).some(tag => tag.toLowerCase().includes(search))
  );
  if (type) filtered = filtered.filter(t => t.type === type);
  if (account) filtered = filtered.filter(t => t.accountId == account);
  if (category) filtered = filtered.filter(t => t.category === category);
  if (tag) filtered = filtered.filter(t => (t.tags || []).includes(tag));
  if (from) filtered = filtered.filter(t => new Date(t.date) >= new Date(from));
  if (to) filtered = filtered.filter(t => new Date(t.date) <= new Date(to + 'T23:59:59'));

  return filtered;
}

function filterTransactions() {
  // Persist the date-from / date-until filters so they're saved and loaded
  // the same every time the Transactions page is opened.
  const s = getState();
  if (!s.settings) s.settings = {};
  s.settings.tx_filter_from = document.getElementById('tx-from-filter')?.value || '';
  s.settings.tx_filter_to = document.getElementById('tx-to-filter')?.value || '';
  saveState();

  const filtered = getFilteredTransactions();
  document.getElementById('tx-table-wrap').innerHTML = renderTransactionTable(filtered);
  const summaryWrap = document.getElementById('tx-summary-wrap');
  if (summaryWrap) summaryWrap.innerHTML = renderTransactionSummary(filtered);
}

function clearTxDateFilter() {
  const s = getState();
  if (!s.settings) s.settings = {};
  s.settings.tx_filter_from = '';
  s.settings.tx_filter_to = '';
  saveState();
  refreshCurrentPage();
}

function exportTransactionsCSV() {
  const s = getState();
  const filtered = getFilteredTransactions();

  if (filtered.length === 0) {
    showToast('No transactions to export', 'error');
    return;
  }

  const headers = ['date', 'type', 'amount', 'currency', 'account', 'description', 'category', 'tags', 'notes', 'conversionRate'];
  const esc = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';

  // Summary header section — same totals shown on the Transactions page,
  // included at the top of the export so the CSV matches what's on screen.
  const base = s.baseCurrency;
  const totalIncome = filtered
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + transactionAmountInBase(t), 0);
  const totalExpense = filtered
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + transactionAmountInBase(t), 0);
  const diff = totalIncome - totalExpense;

  const lines = [
    esc('Total Income') + ',' + esc(formatCurrency(totalIncome, base)),
    esc('Total Expense') + ',' + esc(formatCurrency(totalExpense, base)),
    esc('Difference (Income - Expense)') + ',' + esc(formatCurrency(diff, base)),
    '',
    headers.join(','),
  ];
  filtered.forEach(t => {
    const acc = s.accounts.find(a => a.id == t.accountId);
    const row = [
      t.date ? t.date.split('T')[0] : '',
      t.type || '',
      t.amount != null ? t.amount : '',
      t.currency || '',
      acc ? acc.name : '',
      t.description || '',
      t.category || '',
      (t.tags || []).join(';'),
      t.notes || '',
      t.conversionRate || '',
    ];
    lines.push(row.map(esc).join(','));
  });

  const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  const stamp = new Date().toISOString().split('T')[0];
  a.download = `fintrack-transactions-${stamp}.csv`;
  a.click();
  showToast('Transactions exported', 'success');
}

// Opens the New Transaction modal from the All Transactions page, preselecting
// whatever account the list is currently filtered to (if any), so entering a
// transaction while looking at one account's history doesn't force reselecting it.
function openNewTransactionFromList() {
  const filterVal = document.getElementById('tx-account-filter')?.value || '';
  showTransactionModal(null, filterVal || null);
}

// ══════════════════════════════════════════════
//  FUZZY-SEARCH COMBOBOX (accounts / categories)
// ══════════════════════════════════════════════
// Lightweight subsequence-based fuzzy matcher — "chk" matches "Checking",
// "grc" matches "Groceries", etc. Good enough for short account/category lists
// without pulling in a dependency.
function fuzzyMatch(needle, haystack) {
  needle = (needle || '').toLowerCase();
  haystack = (haystack || '').toLowerCase();
  if (!needle) return true;
  let i = 0;
  for (let j = 0; j < haystack.length && i < needle.length; j++) {
    if (haystack[j] === needle[i]) i++;
  }
  return i === needle.length;
}

window._ftComboRegistry = window._ftComboRegistry || {};

function registerCombobox(id, options, onSelect) {
  window._ftComboRegistry[id] = { options, onSelect };
}

function comboboxHTML(id, options, selectedValue, placeholder) {
  const selected = options.find(o => String(o.value) === String(selectedValue));
  registerCombobox(id, options);
  return `
    <div class="ft-combobox">
      <input type="text" id="${id}-search" class="ft-combo-input" autocomplete="off" placeholder="${placeholder || 'Search...'}"
        value="${selected ? escHtml(selected.label) : ''}"
        data-input="filterComboboxOptions('${id}')"
        data-action="showComboboxDropdown('${id}')"
        data-blur="hideComboboxDropdownDelayed('${id}')">
      <input type="hidden" id="${id}" value="${selected ? selected.value : ''}">
      <div class="ft-combo-dropdown" id="${id}-dropdown" style="display:none"></div>
    </div>
  `;
}

function filterComboboxOptions(id) {
  const reg = window._ftComboRegistry[id];
  const input = document.getElementById(id + '-search');
  const dropdown = document.getElementById(id + '-dropdown');
  if (!reg || !input || !dropdown) return;
  const q = input.value;
  const matches = reg.options.filter(o => fuzzyMatch(q, o.label)).slice(0, 60);
  dropdown.innerHTML = matches.length
    ? matches.map(o => `<div class="ft-combo-option" data-action="chooseComboboxOption('${id}','${String(o.value).replace(/'/g, "\\'")}')">${o.label}</div>`).join('')
    : `<div class="ft-combo-empty">No matches</div>`;
  dropdown.style.display = 'block';
}

function showComboboxDropdown(id) {
  filterComboboxOptions(id);
}

function hideComboboxDropdown(id) {
  const dropdown = document.getElementById(id + '-dropdown');
  if (dropdown) dropdown.style.display = 'none';
}

// Delayed hide so a click on a dropdown option registers before blur closes it.
function hideComboboxDropdownDelayed(id) {
  setTimeout(function () { hideComboboxDropdown(id); }, 150);
}

function chooseComboboxOption(id, value) {
  const reg = window._ftComboRegistry[id];
  if (!reg) return;
  const opt = reg.options.find(o => String(o.value) === String(value));
  const input = document.getElementById(id + '-search');
  const hidden = document.getElementById(id);
  if (input) input.value = opt ? opt.label : '';
  if (hidden) hidden.value = value;
  hideComboboxDropdown(id);
  if (reg.onSelect) reg.onSelect(value);
}

// ══════════════════════════════════════════════
//  TAG AUTOSUGGEST (comma-separated tags input)
// ══════════════════════════════════════════════
// Shows suggestions matching whatever the person is currently typing after
// the last comma; clicking a suggestion appends it and re-focuses for the
// next tag. New tags typed here get auto-saved to the tag list on submit
// (existing saveTransaction/saveRecurring logic already does this).
function filterTagSuggestions(inputId) {
  const s = getState();
  const input = document.getElementById(inputId);
  const dropdown = document.getElementById(inputId + '-suggest');
  if (!input || !dropdown) return;
  const raw = input.value;
  const parts = raw.split(',');
  const current = parts[parts.length - 1].trim().toLowerCase();
  const already = parts.slice(0, -1).map(t => t.trim().toLowerCase());

  const matches = (s.tags || [])
    .filter(t => !already.includes(t.toLowerCase()))
    .filter(t => current === '' || t.toLowerCase().includes(current))
    .slice(0, 20);

  if (!matches.length || (current === '' && raw !== '')) {
    dropdown.style.display = 'none';
    return;
  }
  dropdown.innerHTML = matches.map(t => `<div class="ft-combo-option" data-action="chooseTagSuggestion('${inputId}','${t.replace(/'/g, "\\'")}')">${t}</div>`).join('');
  dropdown.style.display = 'block';
}

function chooseTagSuggestion(inputId, tag) {
  const input = document.getElementById(inputId);
  if (!input) return;
  const parts = input.value.split(',').map(t => t.trim()).filter(Boolean);
  parts.pop(); // drop the partial fragment being typed
  parts.push(tag);
  input.value = parts.join(', ') + ', ';
  hideTagSuggestDelayed(inputId);
  input.focus();
}

function hideTagSuggestDelayed(inputId) {
  setTimeout(function () {
    const dropdown = document.getElementById(inputId + '-suggest');
    if (dropdown) dropdown.style.display = 'none';
  }, 150);
}

function tagAutosuggestHTML(inputId, value, placeholder) {
  return `
    <div class="ft-combobox">
      <input id="${inputId}" placeholder="${placeholder || 'e.g. food, monthly'}" value="${value || ''}"
        data-input="filterTagSuggestions('${inputId}')"
        data-action="filterTagSuggestions('${inputId}')"
        data-blur="hideTagSuggestDelayed('${inputId}')" autocomplete="off">
      <div class="ft-combo-dropdown" id="${inputId}-suggest" style="display:none"></div>
    </div>
  `;
}

function showTransactionModal(txId, defaultAccountId, readOnly) {
  const s = getState();
  const tx = txId ? s.transactions.find(t => t.id == txId) : null;
  const ro = !!readOnly;
  const dis = ro ? 'disabled' : '';

  // Inactive accounts can't be picked for new/edited transactions — except the
  // transaction's own current account, so existing history still displays correctly.
  const accountOptions = s.accounts
    .filter(a => a.active || (tx && tx.accountId == a.id))
    .map(a => ({
      value: a.id,
      label: `${a.icon || ''} ${a.name} (${a.currency})${!a.active ? ' — inactive' : ''}`,
    }));
  const categoryOptions = s.categories.map(c => ({ value: c.name, label: `${c.icon || ''} ${c.name}` }));

  openModal(ro ? 'Transaction Details' : (tx ? 'Edit Transaction' : 'New Transaction'), `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group">
          <label>Type *</label>
          <select id="tx-type" ${dis}>
            <option value="income" ${tx?.type === 'income' ? 'selected' : ''}>Income</option>
            <option value="expense" ${!tx || tx?.type === 'expense' ? 'selected' : ''}>Expense</option>
          </select>
        </div>
        <div class="form-group">
          <label>Account *</label>
          ${comboboxHTML('tx-account', accountOptions, tx?.accountId || defaultAccountId, 'Search accounts…')}
        </div>
        <div class="form-group">
          <label>Amount *</label>
          <input id="tx-amount" type="number" step="0.01" placeholder="0.00" value="${tx?.amount || ''}" ${dis}>
        </div>
        <div class="form-group">
          <label>Date *</label>
          <input id="tx-date" type="date" value="${tx ? tx.date.split('T')[0] : new Date().toISOString().split('T')[0]}" ${dis}>
        </div>
        <div class="form-group" id="tx-convrate-wrap" style="display:none">
          <label id="tx-convrate-label">Conversion Rate</label>
          <div style="display:flex;gap:6px">
            <input id="tx-convrate" type="number" step="0.00000001" min="0" placeholder="e.g. 3.75" value="${tx?.conversionRate || ''}" style="flex:1" ${dis}>
            ${!ro ? `<button type="button" id="tx-convrate-fetch" class="btn btn-secondary btn-sm" data-action="fetchOnlineRate('','','tx-convrate',el)">Fetch online</button>` : ''}
          </div>
        </div>
        <div class="form-group full">
          <label>Description</label>
          <input id="tx-desc" placeholder="What was this for?" value="${tx?.description || ''}" ${dis}>
        </div>
        <div class="form-group">
          <label style="display:flex;align-items:center;justify-content:space-between">
            <span>Category</span>
            ${!ro ? `<a href="#" data-action="toggleTxCategoryQuickAdd()" style="font-size:12px;font-weight:500">+ New category</a>` : ''}
          </label>
          ${comboboxHTML('tx-category', categoryOptions, tx?.category || '', 'Search categories…')}
          <div id="tx-cat-quickadd" style="display:none;margin-top:8px;padding:10px;border:1px solid var(--border);border-radius:var(--radius);background:var(--bg-2)">
            <div class="form-grid" style="gap:8px">
              <input id="tx-cat-quickadd-name" placeholder="Category name" style="grid-column:span 2">
              <select id="tx-cat-quickadd-type">
                <option value="expense" ${(!tx || tx?.type === 'expense') ? 'selected' : ''}>Expense</option>
                <option value="income" ${tx?.type === 'income' ? 'selected' : ''}>Income</option>
              </select>
              <input id="tx-cat-quickadd-icon" placeholder="🎬 (icon)" style="font-size:16px">
            </div>
            <div style="display:flex;gap:8px;margin-top:8px">
              <button type="button" class="btn btn-secondary btn-sm" data-action="toggleTxCategoryQuickAdd()">Cancel</button>
              <button type="button" class="btn btn-primary btn-sm" data-action="quickAddCategoryFromTx()">Add category</button>
            </div>
          </div>
        </div>
        <div class="form-group">
          <label>Tags (comma-separated)</label>
          ${ro
            ? `<input id="tx-tags" value="${(tx?.tags || []).join(', ')}" disabled>`
            : tagAutosuggestHTML('tx-tags', (tx?.tags || []).join(', '))}
        </div>
        <div class="form-group full">
          <label>Notes</label>
          <textarea id="tx-notes" placeholder="Additional notes..." ${dis}>${tx?.notes || ''}</textarea>
        </div>
      </div>
      <div class="form-actions">
        ${ro
          ? `<button class="btn btn-secondary" data-action="closeModal()">Close</button>
             <button class="btn btn-primary" data-action="showTransactionModal('${txId}')">Edit</button>`
          : `<button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
             <button class="btn btn-primary" data-action="saveTransaction('${txId || ''}')">${tx ? 'Save Changes' : 'Add Transaction'}</button>`}
      </div>
    </div>
  `);
  // Wire the account combobox's onSelect to refresh the conversion-rate field.
  if (window._ftComboRegistry['tx-account']) {
    window._ftComboRegistry['tx-account'].onSelect = function () { updateTxConversionRateField(tx); };
  }
  updateTxConversionRateField(tx);
}

/**
 * Show/hide and label the "Conversion Rate" field on the transaction form
 * based on whether the selected account's currency differs from the base
 * currency. When shown, prefill it with:
 *   1. the transaction's own previously-saved rate (when editing), else
 *   2. the currency's current rate on file (a sensible starting point).
 * Nothing here forces a value — the person can always type a different
 * rate that reflects what applied on the transaction's actual date.
 */
function updateTxConversionRateField(tx) {
  const s = getState();
  const base = s.baseCurrency;
  const accountId = document.getElementById('tx-account')?.value;
  const acc = s.accounts.find(a => a.id == accountId);
  const wrap = document.getElementById('tx-convrate-wrap');
  const label = document.getElementById('tx-convrate-label');
  const input = document.getElementById('tx-convrate');
  const fetchBtn = document.getElementById('tx-convrate-fetch');
  if (!wrap || !input || !acc) return;

  if (acc.currency === base) {
    wrap.style.display = 'none';
    input.value = '';
    return;
  }

  wrap.style.display = '';
  if (label) label.textContent = `Conversion Rate (1 ${acc.currency} = ? ${base})`;
  if (fetchBtn) fetchBtn.setAttribute('data-action', `fetchOnlineRate('${acc.currency}','${base}','tx-convrate',el)`);
  if (!input.value) {
    const existingRate = (tx && tx.currency === acc.currency && tx.conversionRate)
      ? tx.conversionRate
      : getRate(acc.currency, base);
    input.value = existingRate || '';
  }
}

function toggleTxCategoryQuickAdd() {
  const panel = document.getElementById('tx-cat-quickadd');
  if (!panel) return;
  const showing = panel.style.display !== 'none';
  panel.style.display = showing ? 'none' : 'block';
  if (!showing) {
    const nameInput = document.getElementById('tx-cat-quickadd-name');
    if (nameInput) nameInput.focus();
  }
}

function quickAddCategoryFromTx() {
  if (typeof window._ftQuickAddCategoryFromTx === 'function') { window._ftQuickAddCategoryFromTx(); return; }

  // Standalone fallback — no server round-trip, just push into local state.
  const state = getState();
  const name = document.getElementById('tx-cat-quickadd-name').value.trim();
  if (!name) { showToast('Category name required', 'error'); return; }
  const cat = {
    id: generateId('cat'),
    name,
    type: document.getElementById('tx-cat-quickadd-type').value,
    icon: document.getElementById('tx-cat-quickadd-icon').value.trim(),
    color: '#4f8ef7',
  };
  state.categories.push(cat);
  saveState();
  applyNewCategoryToTxForm(cat);
}

/**
 * Shared by both the API-backed (fintrack-main.js) and standalone quick-add
 * paths: append the new category to the transaction modal's dropdown, select
 * it, reset/hide the quick-add panel, and let the person continue filling
 * out the rest of the transaction without losing anything they've entered.
 */
function applyNewCategoryToTxForm(cat) {
  // tx-category is now a fuzzy-search combobox (hidden input + visible search
  // box), not a <select> — add the new category to its registry and select it.
  const reg = window._ftComboRegistry && window._ftComboRegistry['tx-category'];
  const label = (cat.icon ? cat.icon + ' ' : '') + cat.name;
  if (reg) {
    reg.options.push({ value: cat.name, label });
  }
  const hidden = document.getElementById('tx-category');
  const search = document.getElementById('tx-category-search');
  if (hidden) hidden.value = cat.name;
  if (search) search.value = label;
  const nameInput = document.getElementById('tx-cat-quickadd-name');
  if (nameInput) nameInput.value = '';
  const iconInput = document.getElementById('tx-cat-quickadd-icon');
  if (iconInput) iconInput.value = '';
  toggleTxCategoryQuickAdd();
  showToast('Category added', 'success');
}

function saveTransaction(txId) {
  if (typeof window._ftSaveTransaction === 'function') { window._ftSaveTransaction(txId); return; }
  const state = getState();
  const amount = parseFloat(document.getElementById('tx-amount').value);
  const accountId = document.getElementById('tx-account').value;
  if (!amount || amount <= 0) { showToast('Enter a valid amount', 'error'); return; }
  if (!accountId) { showToast('Select an account', 'error'); return; }

  const acc = state.accounts.find(a => a.id == accountId);
  const tagsRaw = document.getElementById('tx-tags').value;
  const tags = tagsRaw.split(',').map(t => t.trim()).filter(Boolean);

  // Save new tags
  tags.forEach(tag => { if (!state.tags.includes(tag)) state.tags.push(tag); });

  // Conversion rate to the base currency — only meaningful when this
  // transaction's currency differs from the base currency. Saving it here
  // also updates the currency's own rate on file, so the two stay in sync.
  let conversionRate = null;
  if (acc.currency !== state.baseCurrency) {
    const rateInput = document.getElementById('tx-convrate');
    const rateVal = rateInput ? parseFloat(rateInput.value) : NaN;
    if (rateVal > 0) {
      conversionRate = rateVal;
      const cur = state.currencies.find(c => c.code === acc.currency);
      if (cur) cur.rate = rateVal;
    }
  }

  const data = {
    type: document.getElementById('tx-type').value,
    accountId,
    amount,
    currency: acc.currency,
    conversionRate,
    description: document.getElementById('tx-desc').value.trim(),
    category: document.getElementById('tx-category').value,
    tags,
    notes: document.getElementById('tx-notes').value.trim(),
    date: new Date(document.getElementById('tx-date').value).toISOString(),
  };

  if (txId) {
    const tx = state.transactions.find(t => t.id == txId);
    if (tx) Object.assign(tx, data);
    showToast('Transaction updated', 'success');
  } else {
    state.transactions.push({ id: generateId('tx'), ...data, created: new Date().toISOString() });
    showToast('Transaction added', 'success');
  }

  saveState();
  closeModal();
  refreshCurrentPage();
}

function deleteTransaction(txId) {
  if (typeof window._ftDeleteTransaction === 'function') { window._ftDeleteTransaction(txId); return; }
  const state = getState();
  state.transactions = state.transactions.filter(t => t.id != txId);
  saveState();
  showToast('Transaction deleted', 'success');
  refreshCurrentPage();
}

// ── Transfers ──
function renderTransfersPage() {
  const s = getState();
  const page = document.getElementById('page-transfers');
  const sorted = [...s.transfers].sort((a, b) => new Date(b.date) - new Date(a.date));

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Transfers</div>
        <div class="page-subtitle">Move money between accounts with automatic currency conversion</div>
      </div>
      <button class="btn btn-primary" data-action="showTransferModal()">
        <svg viewBox="0 0 24 24"><path d="M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z"/></svg>
        New Transfer
      </button>
    </div>

    <div class="content">
      <div class="card">
        ${sorted.length === 0 ? `
          <div class="empty-state">
            <svg viewBox="0 0 24 24"><path d="M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z"/></svg>
            <div class="empty-title">No transfers yet</div>
            <p>Create a transfer to move money between your accounts.</p>
          </div>
        ` : `
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>From</th>
                  <th>To</th>
                  <th>From Amount</th>
                  <th>To Amount</th>
                  <th>Rate</th>
                  <th>Description</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                ${sorted.map(tr => {
                  const from = s.accounts.find(a => a.id == tr.fromAccountId);
                  const to = s.accounts.find(a => a.id == tr.toAccountId);
                  return `
                    <tr>
                      <td class="td-muted">${new Date(tr.date).toLocaleDateString()}</td>
                      <td>${from ? `<span class="chip">${from.icon || ''} ${from.name}</span>` : '—'}</td>
                      <td>${to ? `<span class="chip">${to.icon || ''} ${to.name}</span>` : '—'}</td>
                      <td class="td-mono td-red">-${formatCurrency(tr.fromAmount, tr.fromCurrency)}</td>
                      <td class="td-mono td-green">+${formatCurrency(tr.toAmount, tr.toCurrency)}</td>
                      <td class="td-mono td-muted">${tr.fromCurrency !== tr.toCurrency ? `1 ${tr.fromCurrency} = ${tr.conversionRate.toFixed(4)} ${tr.toCurrency}` : '—'}</td>
                      <td>${tr.description || '—'}</td>
                      <td>
                        <button class="btn btn-danger btn-icon btn-sm" data-action="deleteTransfer('${tr.id}')">
                          <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12z"/></svg>
                        </button>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>
    </div>
  `;
}

function showTransferModal() {
  const s = getState();
  openModal('New Transfer', `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group">
          <label>From Account *</label>
          <select id="tr-from" data-change="updateTransferConversion()">
            ${s.accounts.map(a => `<option value="${a.id}">${a.icon || ''} ${a.name} (${a.currency})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>To Account *</label>
          <select id="tr-to" data-change="updateTransferConversion()">
            ${s.accounts.map((a, i) => `<option value="${a.id}" ${i===1?'selected':''}>${a.icon || ''} ${a.name} (${a.currency})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Amount *</label>
          <input id="tr-amount" type="number" step="0.01" placeholder="0.00" data-input="updateTransferConversion()">
        </div>
        <div class="form-group">
          <label>Date *</label>
          <input id="tr-date" type="date" value="${new Date().toISOString().split('T')[0]}">
        </div>
      </div>
      <div id="tr-conversion-info" class="conversion-info" style="display:none"></div>
      <div class="form-group" id="tr-convrate-wrap" style="display:none">
        <label id="tr-convrate-label">Conversion Rate</label>
        <div style="display:flex;gap:6px">
          <input id="tr-convrate" type="number" step="0.00000001" min="0" placeholder="e.g. 3.75" style="flex:1" data-input="updateTransferConversion()">
          <button type="button" id="tr-convrate-fetch" class="btn btn-secondary btn-sm" data-action="fetchOnlineRate('','','tr-convrate',el)">Fetch online</button>
        </div>
      </div>
      <div class="form-group">
        <label>Description</label>
        <input id="tr-desc" placeholder="What is this transfer for?">
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-primary" data-action="saveTransfer()">Create Transfer</button>
      </div>
    </div>
  `);
  setTimeout(updateTransferConversion, 100);
}

function updateTransferConversion() {
  const fromEl = document.getElementById('tr-from');
  const toEl = document.getElementById('tr-to');
  const amountEl = document.getElementById('tr-amount');
  const infoEl = document.getElementById('tr-conversion-info');
  const rateWrap = document.getElementById('tr-convrate-wrap');
  const rateLabel = document.getElementById('tr-convrate-label');
  const rateInput = document.getElementById('tr-convrate');
  const fetchBtn = document.getElementById('tr-convrate-fetch');
  if (!fromEl || !toEl || !infoEl) return;

  const s = getState();
  const fromAcc = s.accounts.find(a => a.id == fromEl.value);
  const toAcc = s.accounts.find(a => a.id == toEl.value);
  if (!fromAcc || !toAcc) return;

  const amount = parseFloat(amountEl?.value || 0);
  if (fromAcc.currency !== toAcc.currency) {
    const rate = (rateInput && parseFloat(rateInput.value) > 0) ? parseFloat(rateInput.value) : getRate(fromAcc.currency, toAcc.currency);
    const converted = amount * rate;
    infoEl.style.display = 'block';
    infoEl.innerHTML = amount > 0
      ? `${formatCurrency(amount, fromAcc.currency)} → <strong>${formatCurrency(converted, toAcc.currency)}</strong> · Rate: 1 ${fromAcc.currency} = ${rate.toFixed(6)} ${toAcc.currency}`
      : `Different currencies detected · 1 ${fromAcc.currency} = ${rate.toFixed(6)} ${toAcc.currency}`;

    if (rateWrap) rateWrap.style.display = '';
    if (rateLabel) rateLabel.textContent = `Conversion Rate (1 ${fromAcc.currency} = ? ${toAcc.currency})`;
    if (fetchBtn) fetchBtn.setAttribute('data-action', `fetchOnlineRate('${fromAcc.currency}','${toAcc.currency}','tr-convrate',el)`);
    if (rateInput && !rateInput.value) rateInput.value = getRate(fromAcc.currency, toAcc.currency) || '';
  } else {
    infoEl.style.display = 'none';
    if (rateWrap) rateWrap.style.display = 'none';
    if (rateInput) rateInput.value = '';
  }
}

function saveTransfer() {
  if (typeof window._ftSaveTransfer === 'function') { window._ftSaveTransfer(); return; }
  const state = getState();
  const s = getState();
  const fromId = document.getElementById('tr-from').value;
  const toId = document.getElementById('tr-to').value;
  const amount = parseFloat(document.getElementById('tr-amount').value);
  const date = document.getElementById('tr-date').value;

  if (fromId === toId) { showToast('Cannot transfer to the same account', 'error'); return; }
  if (!amount || amount <= 0) { showToast('Enter a valid amount', 'error'); return; }

  const fromAcc = s.accounts.find(a => a.id == fromId);
  const toAcc = s.accounts.find(a => a.id == toId);
  const rate = getRate(fromAcc.currency, toAcc.currency);
  const toAmount = amount * rate;

  state.transfers.push({
    id: generateId('tr'),
    fromAccountId: fromId,
    toAccountId: toId,
    fromAmount: amount,
    toAmount,
    fromCurrency: fromAcc.currency,
    toCurrency: toAcc.currency,
    conversionRate: rate,
    description: document.getElementById('tr-desc').value.trim(),
    date: new Date(date).toISOString(),
    created: new Date().toISOString(),
  });

  saveState();
  showToast('Transfer created', 'success');
  closeModal();
  renderTransfersPage();
}

function deleteTransfer(trId) {
  if (typeof window._ftDeleteTransfer === 'function') { window._ftDeleteTransfer(trId); return; }
  const state = getState();
  state.transfers = state.transfers.filter(t => t.id != trId);
  saveState();
  showToast('Transfer deleted', 'success');
  renderTransfersPage();
}
// FinTrack — Budgets Module

function renderBudgetsPage() {
  const s = getState();
  const page = document.getElementById('page-budgets');

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Budgets</div>
        <div class="page-subtitle">Set spending limits and track your progress</div>
      </div>
      <button class="btn btn-primary" data-action="showBudgetModal()">
        <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
        New Budget
      </button>
    </div>

    <div class="content">
      ${s.budgets.length === 0 ? `
        <div class="empty-state">
          <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 14l-5-5 1.41-1.41L12 14.17l7.59-7.59L21 8l-9 9z"/></svg>
          <div class="empty-title">No budgets yet</div>
          <p>Create budgets to control your spending and reach your financial goals.</p>
          <br>
          <button class="btn btn-primary" data-action="showBudgetModal()">Create Budget</button>
        </div>
      ` : `
        <div class="accounts-grid">
          ${s.budgets.map(b => renderBudgetCard(b)).join('')}
        </div>
      `}
    </div>
  `;
}

function renderBudgetCard(budget) {
  const spent = getCategorySpend(budget.category, budget.period);
  const pct = budget.limit > 0 ? Math.min((spent / budget.limit) * 100, 100) : 0;
  const remaining = budget.limit - spent;
  const isOver = spent > budget.limit;
  const isWarning = pct >= 80;

  return `
    <div class="budget-card">
      <div class="budget-header">
        <div>
          <div class="budget-name">${budget.name}</div>
          <div class="budget-period">${capitalise(budget.period)} · ${budget.category}</div>
        </div>
        <div style="display:flex;gap:4px">
          <button class="btn btn-ghost btn-icon btn-sm" data-action="showBudgetModal('${budget.id}')">
            <svg viewBox="0 0 24 24" style="width:14px;height:14px;fill:currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>
          </button>
          <button class="btn btn-danger btn-icon btn-sm" data-action="deleteBudget('${budget.id}')">
            <svg viewBox="0 0 24 24" style="width:14px;height:14px;fill:currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12z"/></svg>
          </button>
        </div>
      </div>

      <div class="progress-bar">
        <div class="progress-fill ${isOver ? 'danger' : isWarning ? 'warning' : ''}" style="width:${pct}%"></div>
      </div>

      <div class="budget-amounts">
        <span>
          <span class="spent" style="color:${isOver ? 'var(--red)' : 'var(--text)'}">${formatCurrency(spent, budget.currency)}</span>
          <span style="color:var(--text-3)"> spent of </span>
          <span class="limit">${formatCurrency(budget.limit, budget.currency)}</span>
        </span>
        <span style="color:${isOver ? 'var(--red)' : remaining < budget.limit * 0.2 ? 'var(--yellow)' : 'var(--green)'}">
          ${isOver ? `Over by ${formatCurrency(Math.abs(remaining), budget.currency)}` : `${formatCurrency(remaining, budget.currency)} left`}
        </span>
      </div>

      <div style="margin-top:8px;font-size:11.5px;color:var(--text-3)">${pct.toFixed(1)}% used</div>
    </div>
  `;
}

function showBudgetModal(budgetId) {
  const s = getState();
  const b = budgetId ? s.budgets.find(x => x.id == budgetId) : null;

  openModal(b ? 'Edit Budget' : 'New Budget', `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group full">
          <label>Budget Name *</label>
          <input id="b-name" placeholder="e.g. Monthly Groceries" value="${b?.name || ''}">
        </div>
        <div class="form-group">
          <label>Spending Limit *</label>
          <input id="b-limit" type="number" step="0.01" placeholder="0.00" value="${b?.limit || ''}">
        </div>
        <div class="form-group">
          <label>Currency</label>
          <select id="b-currency">
            ${s.currencies.map(c => `<option value="${c.code}" ${(b?.currency || s.baseCurrency) === c.code ? 'selected' : ''}>${c.code}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Period *</label>
          <select id="b-period">
            <option value="weekly" ${b?.period === 'weekly' ? 'selected' : ''}>Weekly</option>
            <option value="monthly" ${!b || b?.period === 'monthly' ? 'selected' : ''}>Monthly</option>
            <option value="quarterly" ${b?.period === 'quarterly' ? 'selected' : ''}>Quarterly</option>
            <option value="yearly" ${b?.period === 'yearly' ? 'selected' : ''}>Yearly</option>
          </select>
        </div>
        <div class="form-group">
          <label>Category</label>
          <select id="b-category">
            <option value="">— Any —</option>
            ${s.categories.map(c => `<option value="${c.name}" ${b?.category === c.name ? 'selected' : ''}>${c.icon || ''} ${c.name}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Start Date</label>
          <input id="b-start" type="date" value="${b ? b.startDate?.split('T')[0] : new Date().toISOString().split('T')[0]}">
        </div>
        <div class="form-group">
          <label>Status</label>
          <select id="b-active">
            <option value="true" ${!b || b.active ? 'selected' : ''}>Active</option>
            <option value="false" ${b && !b.active ? 'selected' : ''}>Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-primary" data-action="saveBudget('${budgetId || ''}')">
          ${b ? 'Save Changes' : 'Create Budget'}
        </button>
      </div>
    </div>
  `);
}

function saveBudget(budgetId) {
  if (typeof window._ftSaveBudget === 'function') { window._ftSaveBudget(budgetId); return; }
  const state = getState();
  const name = document.getElementById('b-name').value.trim();
  const limit = parseFloat(document.getElementById('b-limit').value);
  if (!name) { showToast('Budget name required', 'error'); return; }
  if (!limit || limit <= 0) { showToast('Enter a valid limit', 'error'); return; }

  const data = {
    name,
    limit,
    currency: document.getElementById('b-currency').value,
    period: document.getElementById('b-period').value,
    category: document.getElementById('b-category').value,
    startDate: new Date(document.getElementById('b-start').value).toISOString(),
    active: document.getElementById('b-active').value === 'true',
  };

  if (budgetId) {
    const b = state.budgets.find(x => x.id == budgetId);
    if (b) Object.assign(b, data);
    showToast('Budget updated', 'success');
  } else {
    state.budgets.push({ id: generateId('bud'), ...data, created: new Date().toISOString() });
    showToast('Budget created', 'success');
  }

  saveState();
  closeModal();
  renderBudgetsPage();
}

function deleteBudget(budgetId) {
  if (typeof window._ftDeleteBudget === 'function') { window._ftDeleteBudget(budgetId); return; }
  const state = getState();
  state.budgets = state.budgets.filter(b => b.id != budgetId);
  saveState();
  showToast('Budget deleted', 'success');
  renderBudgetsPage();
}

function capitalise(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }
// FinTrack — Categories & Tags Module

function renderCategoriesPage() {
  const s = getState();
  const page = document.getElementById('page-categories');

  const grouped = {
    income: s.categories.filter(c => c.type === 'income'),
    expense: s.categories.filter(c => c.type === 'expense'),
    transfer: s.categories.filter(c => c.type === 'transfer'),
  };

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Categories & Tags</div>
        <div class="page-subtitle">Organise and classify your transactions</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary" data-action="showTagModal()">Manage Tags</button>
        <button class="btn btn-primary" data-action="showCategoryModal()">
          <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
          New Category
        </button>
      </div>
    </div>

    <div class="content">
      ${['income', 'expense', 'transfer'].map(type => `
        <div style="margin-bottom:24px">
          <h3 style="font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:0.6px;color:var(--text-3);margin-bottom:12px">${type} Categories</h3>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
            ${grouped[type].map(cat => `
              <div style="background:var(--bg-2);border:1px solid var(--border);border-radius:var(--radius);padding:14px 16px;display:flex;align-items:center;justify-content:space-between">
                <div style="display:flex;align-items:center;gap:10px">
                  <span style="font-size:20px">${cat.icon || '📂'}</span>
                  <div>
                    <div style="font-size:13.5px;font-weight:500">${cat.name}</div>
                    <div style="font-size:11.5px;color:var(--text-3)">${s.transactions.filter(t => t.category === cat.name).length} txns</div>
                  </div>
                </div>
                <div style="display:flex;gap:4px">
                  <button class="btn btn-ghost btn-icon btn-sm" data-action="showCategoryModal('${cat.id}')">
                    <svg viewBox="0 0 24 24" style="width:13px;height:13px;fill:currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>
                  </button>
                  <button class="btn btn-danger btn-icon btn-sm" data-action="deleteCategory('${cat.id}')">
                    <svg viewBox="0 0 24 24" style="width:13px;height:13px;fill:currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12z"/></svg>
                  </button>
                </div>
              </div>
            `).join('')}
            <button class="btn btn-secondary" style="height:62px;border-style:dashed" data-action="showCategoryModal(null,'${type}')">
              + Add ${type} category
            </button>
          </div>
        </div>
      `).join('')}

      <div class="section-divider"></div>

      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <h3 style="font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:0.6px;color:var(--text-3)">Tags</h3>
          <button class="btn btn-secondary btn-sm" data-action="showTagModal()">Manage Tags</button>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:8px">
          ${s.tags.map(tag => `
            <div style="display:flex;align-items:center;gap:6px;background:var(--bg-2);border:1px solid var(--border);border-radius:20px;padding:5px 12px">
              <span style="font-size:13px">${tag}</span>
              <button data-action="deleteTag('${tag}')" style="background:none;border:none;color:var(--text-3);cursor:pointer;font-size:16px;line-height:1;padding:0">&times;</button>
            </div>
          `).join('')}
          <button class="btn btn-secondary btn-sm" data-action="showTagModal()">+ Add Tag</button>
        </div>
      </div>
    </div>
  `;
}

function showCategoryModal(catId, defaultType) {
  const s = getState();
  const cat = catId ? s.categories.find(c => c.id == catId) : null;

  openModal(cat ? 'Edit Category' : 'New Category', `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group full">
          <label>Name *</label>
          <input id="cat-name" placeholder="e.g. Entertainment" value="${cat?.name || ''}">
        </div>
        <div class="form-group">
          <label>Type *</label>
          <select id="cat-type">
            <option value="income" ${(cat?.type || defaultType) === 'income' ? 'selected' : ''}>Income</option>
            <option value="expense" ${(!cat && !defaultType) || (cat?.type || defaultType) === 'expense' ? 'selected' : ''}>Expense</option>
            <option value="transfer" ${(cat?.type || defaultType) === 'transfer' ? 'selected' : ''}>Transfer</option>
          </select>
        </div>
        <div class="form-group">
          <label>Icon (emoji)</label>
          <input id="cat-icon" placeholder="🎬" value="${cat?.icon || ''}" style="font-size:18px">
        </div>
        <div class="form-group">
          <label>Color</label>
          <input id="cat-color" type="color" value="${cat?.color || '#4f8ef7'}">
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-primary" data-action="saveCategory('${catId || ''}')">
          ${cat ? 'Save' : 'Create Category'}
        </button>
      </div>
    </div>
  `);
}

function saveCategory(catId) {
  // In Nextcloud mode, delegate to the API-backed version registered by fintrack-main.js.
  if (typeof window._ftSaveCategory === 'function') { window._ftSaveCategory(catId); return; }

  // Standalone fallback.
  const state = getState();
  const name = document.getElementById('cat-name').value.trim();
  if (!name) { showToast('Category name required', 'error'); return; }

  const data = {
    name,
    type: document.getElementById('cat-type').value,
    icon: document.getElementById('cat-icon').value.trim(),
    color: document.getElementById('cat-color').value,
  };

  if (catId) {
    const cat = state.categories.find(c => c.id == catId);
    if (cat) Object.assign(cat, data);
    showToast('Category updated', 'success');
  } else {
    state.categories.push({ id: generateId('cat'), ...data });
    showToast('Category created', 'success');
  }

  saveState();
  closeModal();
  renderCategoriesPage();
}

function deleteCategory(catId) {
  if (typeof window._ftDeleteCategory === 'function') { window._ftDeleteCategory(catId); return; }
  const state = getState();
  const cat = state.categories.find(c => c.id == catId);
  if (!cat) return;
  const inUse = state.transactions.some(t => t.category === cat.name);
  if (inUse) { showToast('Category is in use by transactions', 'error'); return; }
  state.categories = state.categories.filter(c => c.id != catId);
  saveState();
  showToast('Category deleted', 'success');
  renderCategoriesPage();
}

function showTagModal() {
  const s = getState();
  openModal('Manage Tags', `
    <div class="form-grid cols-1">
      <div class="form-group">
        <label>Add New Tag</label>
        <div style="display:flex;gap:8px">
          <input id="new-tag-input" placeholder="Tag name..." style="flex:1">
          <button class="btn btn-primary" data-action="addTag()">Add</button>
        </div>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px" id="tags-list">
        ${s.tags.map(tag => `
          <div style="display:flex;align-items:center;gap:6px;background:var(--bg);border:1px solid var(--border);border-radius:20px;padding:5px 12px">
            <span>${tag}</span>
            <button data-action="deleteTag('${tag}');renderTagList()" style="background:none;border:none;color:var(--text-3);cursor:pointer;font-size:16px;line-height:1">&times;</button>
          </div>
        `).join('')}
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal();renderCategoriesPage()">Done</button>
      </div>
    </div>
  `);
}

function addTag() {
  if (typeof window._ftAddTag === 'function') { window._ftAddTag(); return; }
  const state = getState();
  const input = document.getElementById('new-tag-input');
  const tag = input.value.trim().toLowerCase();
  if (!tag) return;
  if (state.tags.includes(tag)) { showToast('Tag already exists', 'error'); return; }
  state.tags.push(tag);
  saveState();
  input.value = '';
  showToast('Tag added', 'success');
  renderTagList();
}

function renderTagList() {
  const state = getState();
  const list = document.getElementById('tags-list');
  if (!list) return;
  list.innerHTML = state.tags.map(tag => `
    <div style="display:flex;align-items:center;gap:6px;background:var(--bg);border:1px solid var(--border);border-radius:20px;padding:5px 12px">
      <span>${tag}</span>
      <button data-action="deleteTag('${tag}');renderTagList()" style="background:none;border:none;color:var(--text-3);cursor:pointer;font-size:16px;line-height:1">&times;</button>
    </div>
  `).join('');
}

function deleteTag(tag) {
  if (typeof window._ftDeleteTag === 'function') { window._ftDeleteTag(tag); return; }
  const state = getState();
  state.tags = state.tags.filter(t => t !== tag);
  saveState();
  if (!document.getElementById('tags-list')) renderCategoriesPage();
}
// FinTrack — Reports Module

// Resolve the currently selected report period. Presets are computed relative
// to today; a custom range is persisted verbatim. Stored in settings so the
// choice survives page switches and reloads.
function getReportRange() {
  const s = getState();
  const rr = (s.settings && s.settings.report_range) || {};
  const preset = rr.preset || '6m';

  if (preset === 'custom' && rr.from && rr.to) {
    return { preset, from: new Date(rr.from + 'T00:00:00'), to: new Date(rr.to + 'T23:59:59') };
  }

  const to = new Date();
  const from = new Date();
  if (preset === '3m') from.setMonth(from.getMonth() - 3);
  else if (preset === '1y') from.setFullYear(from.getFullYear() - 1);
  else from.setMonth(from.getMonth() - 6); // default '6m'

  return { preset: (preset === '3m' || preset === '1y') ? preset : '6m', from, to };
}

function setReportPreset(preset) {
  const s = getState();
  if (!s.settings) s.settings = {};
  s.settings.report_range = { preset };
  saveState();
  renderReportsPage();
}

function setReportCustomRange() {
  const fromVal = document.getElementById('rpt-from-filter')?.value;
  const toVal = document.getElementById('rpt-to-filter')?.value;
  if (!fromVal || !toVal) return;
  if (new Date(fromVal) > new Date(toVal)) { showToast('"From" date must be before "Until" date', 'error'); return; }
  const s = getState();
  if (!s.settings) s.settings = {};
  s.settings.report_range = { preset: 'custom', from: fromVal, to: toVal };
  saveState();
  renderReportsPage();
}

// Full calendar months spanning the selected range (capped at 36 to stay sane
// for very wide custom ranges) — used for the trend chart / monthly table.
function getReportMonths(from, to) {
  const months = [];
  const cursor = new Date(from.getFullYear(), from.getMonth(), 1);
  const end = new Date(to.getFullYear(), to.getMonth(), 1);
  let guard = 0;
  while (cursor <= end && guard < 36) {
    months.push({ year: cursor.getFullYear(), month: cursor.getMonth(), label: cursor.toLocaleString('default', { month: 'short', year: '2-digit' }) });
    cursor.setMonth(cursor.getMonth() + 1);
    guard++;
  }
  if (months.length === 0) {
    months.push({ year: to.getFullYear(), month: to.getMonth(), label: to.toLocaleString('default', { month: 'short', year: '2-digit' }) });
  }
  return months;
}

function renderReportsPage() {
  const s = getState();
  const page = document.getElementById('page-reports');

  const range = getReportRange();
  const months = getReportMonths(range.from, range.to);

  const monthlyData = months.map(m => {
    const income = s.transactions
      .filter(t => t.type === 'income' && new Date(t.date).getFullYear() === m.year && new Date(t.date).getMonth() === m.month)
      .reduce((sum, t) => sum + transactionAmountInBase(t), 0);
    const expense = s.transactions
      .filter(t => t.type === 'expense' && new Date(t.date).getFullYear() === m.year && new Date(t.date).getMonth() === m.month)
      .reduce((sum, t) => sum + transactionAmountInBase(t), 0);
    return { ...m, income, expense, net: income - expense };
  });

  // Transactions that actually fall within the exact selected range (used for
  // the period-level stat cards and the category breakdown below).
  const inRange = s.transactions.filter(t => {
    const d = new Date(t.date);
    return d >= range.from && d <= range.to;
  });
  const periodIncome = inRange.filter(t => t.type === 'income')
    .reduce((sum, t) => sum + transactionAmountInBase(t), 0);
  const periodExpense = inRange.filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + transactionAmountInBase(t), 0);
  const periodNet = periodIncome - periodExpense;
  const periodTransfers = s.transfers.filter(t => {
    const d = new Date(t.date);
    return d >= range.from && d <= range.to;
  });

  // Category breakdown across the whole selected period
  const periodExpenses = inRange.filter(t => t.type === 'expense');
  const catBreakdown = {};
  periodExpenses.forEach(t => {
    const key = t.category || 'Uncategorized';
    catBreakdown[key] = (catBreakdown[key] || 0) + transactionAmountInBase(t);
  });
  const catEntries = Object.entries(catBreakdown).sort((a, b) => b[1] - a[1]);
  const totalCatSpend = catEntries.reduce((s, [, v]) => s + v, 0);

  // Account balances
  const assetAccounts = s.accounts.filter(a => a.type === 'asset' && a.active);
  const totalAssets = assetAccounts.reduce((sum, a) => sum + convertAmount(getAccountBalance(a.id), a.currency, s.baseCurrency), 0);

  const maxBar = Math.max(...monthlyData.map(m => Math.max(m.income, m.expense)), 1);
  const rangeFromStr = range.from.toISOString().split('T')[0];
  const rangeToStr = range.to.toISOString().split('T')[0];
  const savingsMonths = monthlyData.slice(Math.max(0, monthlyData.length - 3));

  page.innerHTML = `
    <div class="page-header no-print">
      <div>
        <div class="page-title">Reports &amp; Analytics</div>
        <div class="page-subtitle">Visual overview of your financial activity</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary" data-action="exportReportPDF()">Export Report</button>
      </div>
    </div>

    <div class="filters-bar no-print" style="align-items:center;flex-wrap:wrap">
      <div style="display:flex;gap:6px">
        <button class="btn btn-sm ${range.preset === '3m' ? 'btn-primary' : 'btn-secondary'}" data-action="setReportPreset('3m')">3 Months</button>
        <button class="btn btn-sm ${range.preset === '6m' ? 'btn-primary' : 'btn-secondary'}" data-action="setReportPreset('6m')">6 Months</button>
        <button class="btn btn-sm ${range.preset === '1y' ? 'btn-primary' : 'btn-secondary'}" data-action="setReportPreset('1y')">1 Year</button>
      </div>
      <div style="display:flex;gap:8px;align-items:center;margin-left:auto">
        <span style="font-size:12px;color:var(--text-3)">Custom range</span>
        <input type="date" id="rpt-from-filter" value="${rangeFromStr}" data-change="setReportCustomRange()">
        <span style="color:var(--text-3);font-size:12px">to</span>
        <input type="date" id="rpt-to-filter" value="${rangeToStr}" data-change="setReportCustomRange()">
      </div>
    </div>

    <div id="ft-report-print-area">
      <div class="ft-print-only-title" style="display:none">
        <h1>FinTrack — Reports &amp; Analytics</h1>
        <p>${months[0]?.label} – ${months[months.length - 1]?.label} · Base currency: ${s.baseCurrency} · Generated ${new Date().toLocaleDateString()}</p>
      </div>

      <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-label">Period Income</div>
        <div class="stat-value green">${formatCurrency(periodIncome, s.baseCurrency)}</div>
        <div class="stat-sub">${months[0]?.label} – ${months[months.length - 1]?.label}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Period Expenses</div>
        <div class="stat-value red">${formatCurrency(periodExpense, s.baseCurrency)}</div>
        <div class="stat-sub">${months[0]?.label} – ${months[months.length - 1]?.label}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Period Net</div>
        <div class="stat-value ${periodNet >= 0 ? 'accent' : 'red'}">${formatCurrency(periodNet, s.baseCurrency)}</div>
        <div class="stat-sub">Income minus expenses</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Transactions</div>
        <div class="stat-value">${inRange.length}</div>
        <div class="stat-sub">${periodTransfers.length} transfers</div>
      </div>
    </div>

    <div class="content">
      <!-- Income vs Expense Bar Chart -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header">
          <div class="card-title">Income vs Expenses — ${months[0]?.label} to ${months[months.length - 1]?.label}</div>
        </div>
        <div class="card-body">
          <div style="display:flex;align-items:flex-end;gap:12px;height:160px;padding-bottom:28px;position:relative">
            ${monthlyData.map(m => {
              const incH = maxBar > 0 ? (m.income / maxBar) * 130 : 0;
              const expH = maxBar > 0 ? (m.expense / maxBar) * 130 : 0;
              return `
                <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;height:100%;justify-content:flex-end">
                  <div style="display:flex;gap:3px;align-items:flex-end;width:100%;justify-content:center">
                    <div style="width:40%;background:var(--green);opacity:0.8;border-radius:3px 3px 0 0;height:${incH}px;min-height:${m.income > 0 ? 2 : 0}px;transition:height 0.4s ease" title="Income: ${formatCurrency(m.income, s.baseCurrency)}"></div>
                    <div style="width:40%;background:var(--red);opacity:0.8;border-radius:3px 3px 0 0;height:${expH}px;min-height:${m.expense > 0 ? 2 : 0}px;transition:height 0.4s ease" title="Expense: ${formatCurrency(m.expense, s.baseCurrency)}"></div>
                  </div>
                  <div style="font-size:10.5px;color:var(--text-3);text-align:center;position:absolute;bottom:4px">${m.label}</div>
                </div>
              `;
            }).join('')}
          </div>
          <div style="display:flex;gap:16px;margin-top:8px;justify-content:center">
            <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-2)">
              <div style="width:12px;height:12px;background:var(--green);border-radius:2px;opacity:0.8"></div> Income
            </div>
            <div style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-2)">
              <div style="width:12px;height:12px;background:var(--red);border-radius:2px;opacity:0.8"></div> Expenses
            </div>
          </div>
        </div>
      </div>

      <div class="dash-grid" style="gap:16px">
        <!-- Category Breakdown -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Expense Breakdown — Selected Period</div>
          </div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:10px">
            ${catEntries.length === 0
              ? `<p style="color:var(--text-3);font-size:13px">No expenses in the selected period.</p>`
              : catEntries.map(([cat, amt]) => {
                  const pct = totalCatSpend > 0 ? (amt / totalCatSpend) * 100 : 0;
                  const catObj = s.categories.find(c => c.name === cat);
                  return `
                    <div>
                      <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                        <span style="font-size:13px">${catObj?.icon || '📂'} ${cat}</span>
                        <span style="font-size:12px;font-family:var(--mono)">
                          ${formatCurrency(amt, s.baseCurrency)}
                          <span style="color:var(--text-3)">(${pct.toFixed(1)}%)</span>
                        </span>
                      </div>
                      <div class="progress-bar">
                        <div class="progress-fill danger" style="width:${pct}%"></div>
                      </div>
                    </div>
                  `;
                }).join('')
            }
          </div>
        </div>

        <!-- Monthly Trend Table -->
        <div class="card">
          <div class="card-header"><div class="card-title">Monthly Summary</div></div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Month</th><th>Income</th><th>Expenses</th><th>Net</th></tr>
              </thead>
              <tbody>
                ${[...monthlyData].reverse().map(m => `
                  <tr>
                    <td style="font-weight:500">${m.label}</td>
                    <td class="td-mono td-green">${formatCurrency(m.income, s.baseCurrency)}</td>
                    <td class="td-mono td-red">${formatCurrency(m.expense, s.baseCurrency)}</td>
                    <td class="td-mono ${m.net >= 0 ? 'td-green' : 'td-red'}">${m.net >= 0 ? '+' : ''}${formatCurrency(m.net, s.baseCurrency)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Asset Allocation -->
        <div class="card">
          <div class="card-header"><div class="card-title">Asset Allocation</div></div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:10px">
            ${assetAccounts.length === 0
              ? `<p style="color:var(--text-3);font-size:13px">No asset accounts.</p>`
              : assetAccounts.map(acc => {
                  const bal = getAccountBalance(acc.id);
                  const balBase = convertAmount(bal, acc.currency, s.baseCurrency);
                  const pct = totalAssets > 0 ? (balBase / totalAssets) * 100 : 0;
                  return `
                    <div>
                      <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                        <span style="font-size:13px">${acc.icon || ''} ${acc.name}</span>
                        <span style="font-size:12px;font-family:var(--mono)">
                          ${formatCurrency(bal, acc.currency)}
                          <span style="color:var(--text-3)">(${pct.toFixed(1)}%)</span>
                        </span>
                      </div>
                      <div class="progress-bar">
                        <div class="progress-fill" style="width:${pct}%;background:var(--accent)"></div>
                      </div>
                    </div>
                  `;
                }).join('')
            }
          </div>
        </div>

        <!-- Savings Rate -->
        <div class="card">
          <div class="card-header"><div class="card-title">Savings Rate — Last ${savingsMonths.length} Month${savingsMonths.length === 1 ? '' : 's'}</div></div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:14px">
            ${savingsMonths.map(m => {
              const rate = m.income > 0 ? Math.max(0, ((m.income - m.expense) / m.income) * 100) : 0;
              return `
                <div>
                  <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                    <span style="font-size:13px;font-weight:500">${m.label}</span>
                    <span style="font-size:13px;font-family:var(--mono);color:${rate >= 20 ? 'var(--green)' : rate >= 10 ? 'var(--yellow)' : 'var(--red)'}">
                      ${rate.toFixed(1)}%
                    </span>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-fill ${rate >= 20 ? '' : rate >= 10 ? 'warning' : 'danger'}" style="width:${Math.min(rate, 100)}%"></div>
                  </div>
                </div>
              `;
            }).join('')}
            <p style="font-size:12px;color:var(--text-3)">Healthy savings rate: 20%+</p>
          </div>
        </div>
      </div>
    </div>
    </div>
  `;
}

function exportReportPDF() {
  showToast('Preparing a clean PDF — use Save as PDF in the print dialog', 'success');
  window.print();
}
// FinTrack — Recurring Transactions Module

function renderRecurringPage() {
  const s = getState();
  const page = document.getElementById('page-recurring');

  const recurring = s.recurring || [];

  // Check for due transactions
  const due = recurring.filter(r => r.active && isDue(r));

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Recurring Transactions</div>
        <div class="page-subtitle">Automate repeating income and expense entries</div>
      </div>
      <button class="btn btn-primary" data-action="showRecurringModal()">
        <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
        New Recurring
      </button>
    </div>

    ${due.length > 0 ? `
      <div style="margin:16px 28px 0;background:var(--yellow-dim);border:1px solid rgba(240,192,64,0.3);border-radius:var(--radius);padding:14px 18px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:13.5px;font-weight:600;color:var(--yellow)">⏰ ${due.length} recurring transaction${due.length > 1 ? 's' : ''} due</div>
          <div style="font-size:12.5px;color:var(--text-2);margin-top:2px">These transactions are scheduled and ready to post</div>
        </div>
        <button class="btn btn-primary" data-action="postAllDue()">Post All Due</button>
      </div>
    ` : ''}

    <div class="content">
      ${recurring.length === 0 ? `
        <div class="empty-state">
          <svg viewBox="0 0 24 24"><path d="M12 6v3l4 4-4 4v3c-3.31 0-6-2.69-6-6s2.69-6 6-6m0-2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/></svg>
          <div class="empty-title">No recurring transactions</div>
          <p>Set up recurring entries for regular income (salary, rent) or expenses (subscriptions, bills).</p>
          <br>
          <button class="btn btn-primary" data-action="showRecurringModal()">Create Recurring Transaction</button>
        </div>
      ` : `
        <div class="card">
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Account</th>
                  <th>Amount</th>
                  <th>Frequency</th>
                  <th>Next Due</th>
                  <th>Last Posted</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                ${recurring.map(r => {
                  const acc = s.accounts.find(a => a.id == r.accountId);
                  const due = isDue(r);
                  return `
                    <tr>
                      <td style="font-weight:500">${r.name}</td>
                      <td>${acc ? `<span class="chip">${acc.icon || ''} ${acc.name}</span>` : '—'}</td>
                      <td class="td-mono ${r.type === 'income' ? 'td-green' : 'td-red'}">
                        ${r.type === 'income' ? '+' : '-'}${formatCurrency(r.amount, r.currency)}
                      </td>
                      <td><span class="chip">${capitalise(r.frequency)}</span></td>
                      <td class="${due ? 'td-green' : 'td-muted'}" style="font-size:12.5px">
                        ${due ? '⏰ Due now' : r.nextDate ? new Date(r.nextDate).toLocaleDateString() : '—'}
                      </td>
                      <td class="td-muted" style="font-size:12.5px">${r.lastPosted ? new Date(r.lastPosted).toLocaleDateString() : 'Never'}</td>
                      <td>
                        <span class="chip ${r.active ? 'green' : ''}">${r.active ? 'Active' : 'Paused'}</span>
                      </td>
                      <td>
                        <div style="display:flex;gap:4px">
                          ${due ? `<button class="btn btn-primary btn-sm" data-action="postRecurring('${r.id}')">Post</button>` : ''}
                          <button class="btn btn-ghost btn-icon btn-sm" data-action="showRecurringModal('${r.id}')">
                            <svg viewBox="0 0 24 24" style="width:13px;height:13px;fill:currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z"/></svg>
                          </button>
                          <button class="btn btn-secondary btn-sm" data-action="toggleRecurring('${r.id}')">
                            ${r.active ? 'Pause' : 'Resume'}
                          </button>
                          <button class="btn btn-danger btn-icon btn-sm" data-action="deleteRecurring('${r.id}')">
                            <svg viewBox="0 0 24 24" style="width:13px;height:13px;fill:currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12z"/></svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `}
    </div>
  `;
}

function isDue(r) {
  if (!r.active || !r.nextDate) return false;
  return new Date(r.nextDate) <= new Date();
}

function getNextDate(frequency, fromDate) {
  const d = new Date(fromDate || new Date());
  switch (frequency) {
    case 'daily':   d.setDate(d.getDate() + 1); break;
    case 'weekly':  d.setDate(d.getDate() + 7); break;
    case 'biweekly':d.setDate(d.getDate() + 14); break;
    case 'monthly': d.setMonth(d.getMonth() + 1); break;
    case 'quarterly':d.setMonth(d.getMonth() + 3); break;
    case 'yearly':  d.setFullYear(d.getFullYear() + 1); break;
  }
  return d.toISOString();
}

function showRecurringModal(recId) {
  const s = getState();
  const rec = recId ? (s.recurring || []).find(r => r.id == recId) : null;

  openModal(rec ? 'Edit Recurring Transaction' : 'New Recurring Transaction', `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group full">
          <label>Name *</label>
          <input id="rec-name" placeholder="e.g. Monthly Salary, Netflix Subscription" value="${rec?.name || ''}">
        </div>
        <div class="form-group">
          <label>Type *</label>
          <select id="rec-type">
            <option value="expense" ${!rec || rec.type === 'expense' ? 'selected' : ''}>Expense</option>
            <option value="income" ${rec?.type === 'income' ? 'selected' : ''}>Income</option>
          </select>
        </div>
        <div class="form-group">
          <label>Account *</label>
          <select id="rec-account">
            ${s.accounts.map(a => `<option value="${a.id}" ${rec?.accountId == a.id ? 'selected' : ''}>${a.icon || ''} ${a.name} (${a.currency})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Amount *</label>
          <input id="rec-amount" type="number" step="0.01" placeholder="0.00" value="${rec?.amount || ''}">
        </div>
        <div class="form-group">
          <label>Frequency *</label>
          <select id="rec-frequency">
            <option value="daily" ${rec?.frequency === 'daily' ? 'selected' : ''}>Daily</option>
            <option value="weekly" ${rec?.frequency === 'weekly' ? 'selected' : ''}>Weekly</option>
            <option value="biweekly" ${rec?.frequency === 'biweekly' ? 'selected' : ''}>Bi-weekly</option>
            <option value="monthly" ${!rec || rec?.frequency === 'monthly' ? 'selected' : ''}>Monthly</option>
            <option value="quarterly" ${rec?.frequency === 'quarterly' ? 'selected' : ''}>Quarterly</option>
            <option value="yearly" ${rec?.frequency === 'yearly' ? 'selected' : ''}>Yearly</option>
          </select>
        </div>
        <div class="form-group">
          <label>Start / Next Date *</label>
          <input id="rec-start" type="date" value="${rec ? rec.nextDate?.split('T')[0] : new Date().toISOString().split('T')[0]}">
        </div>
        <div class="form-group">
          <label>Category</label>
          <select id="rec-category">
            <option value="">— None —</option>
            ${s.categories.map(c => `<option value="${c.name}" ${rec?.category === c.name ? 'selected' : ''}>${c.icon || ''} ${c.name}</option>`).join('')}
          </select>
        </div>
        <div class="form-group full">
          <label>Description</label>
          <input id="rec-desc" placeholder="Optional description" value="${rec?.description || ''}">
        </div>
        <div class="form-group">
          <label>Tags (comma-separated)</label>
          <input id="rec-tags" placeholder="e.g. recurring, bills" value="${(rec?.tags || []).join(', ')}">
        </div>
        <div class="form-group">
          <label>Status</label>
          <select id="rec-active">
            <option value="true" ${!rec || rec.active ? 'selected' : ''}>Active</option>
            <option value="false" ${rec && !rec.active ? 'selected' : ''}>Paused</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-primary" data-action="saveRecurring('${recId || ''}')">
          ${rec ? 'Save Changes' : 'Create Recurring'}
        </button>
      </div>
    </div>
  `);
}

function saveRecurring(recId) {
  if (typeof window._ftSaveRecurring === 'function') { window._ftSaveRecurring(recId); return; }
  const state = getState();
  const name = document.getElementById('rec-name').value.trim();
  const amount = parseFloat(document.getElementById('rec-amount').value);
  if (!name) { showToast('Name required', 'error'); return; }
  if (!amount || amount <= 0) { showToast('Enter a valid amount', 'error'); return; }

  const accountId = document.getElementById('rec-account').value;
  const acc = state.accounts.find(a => a.id == accountId);
  const tags = document.getElementById('rec-tags').value.split(',').map(t => t.trim()).filter(Boolean);

  const data = {
    name,
    type: document.getElementById('rec-type').value,
    accountId,
    amount,
    currency: acc.currency,
    frequency: document.getElementById('rec-frequency').value,
    nextDate: new Date(document.getElementById('rec-start').value).toISOString(),
    category: document.getElementById('rec-category').value,
    description: document.getElementById('rec-desc').value.trim(),
    tags,
    active: document.getElementById('rec-active').value === 'true',
  };

  if (!state.recurring) state.recurring = [];

  if (recId) {
    const rec = state.recurring.find(r => r.id === recId);
    if (rec) Object.assign(rec, data);
    showToast('Recurring transaction updated', 'success');
  } else {
    state.recurring.push({ id: generateId('rec'), ...data, created: new Date().toISOString() });
    showToast('Recurring transaction created', 'success');
  }

  saveState();
  closeModal();
  renderRecurringPage();
}

function postRecurring(recId) {
  if (typeof window._ftPostRecurring === 'function') { window._ftPostRecurring(recId); return; }
  const state = getState();
  const rec = (state.recurring || []).find(r => r.id === recId);
  if (!rec) return;
  const acc = state.accounts.find(a => a.id == rec.accountId);

  state.transactions.push({
    id: generateId('tx'),
    type: rec.type,
    accountId: rec.accountId,
    amount: rec.amount,
    currency: rec.currency,
    description: rec.description || rec.name,
    category: rec.category,
    tags: [...(rec.tags || []), 'recurring'],
    date: new Date().toISOString(),
    source: 'recurring',
    recurringId: recId,
    created: new Date().toISOString(),
  });

  rec.lastPosted = new Date().toISOString();
  rec.nextDate = getNextDate(rec.frequency, new Date());

  saveState();
  showToast(`Posted: ${rec.name}`, 'success');
  renderRecurringPage();
}

function postAllDue() {
  if (typeof window._ftPostAllDue === 'function') { window._ftPostAllDue(); return; }
  const state = getState();
  const due = (state.recurring || []).filter(r => r.active && isDue(r));
  due.forEach(r => postRecurring(r.id));
  if (due.length > 0) showToast(`Posted ${due.length} recurring transactions`, 'success');
}

function toggleRecurring(recId) {
  if (typeof window._ftToggleRecurring === 'function') { window._ftToggleRecurring(recId); return; }
  const state = getState();
  const rec = (state.recurring || []).find(r => r.id == recId);
  if (rec) { rec.active = !rec.active; saveState(); renderRecurringPage(); }
}

function deleteRecurring(recId) {
  if (typeof window._ftDeleteRecurring === 'function') { window._ftDeleteRecurring(recId); return; }
  const state = getState();
  state.recurring = (state.recurring || []).filter(r => r.id !== recId);
  saveState();
  showToast('Recurring transaction deleted', 'success');
  renderRecurringPage();
}
// FinTrack — Dashboard Module

function renderDashboard() {
  const s = getState();
  const page = document.getElementById('page-dashboard');

  const totalAssets = getTotalByType('asset');
  const totalLiabilities = getTotalByType('liability');
  const netWorth = totalAssets - totalLiabilities;
  const totalRevenue = getTotalByType('revenue');
  const totalExpenses = getTotalByType('expense');
  const cashFlow = totalRevenue - totalExpenses;

  const recentTxs = [...s.transactions]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 8);

  const activeBudgets = s.budgets.filter(b => b.active).slice(0, 4);

  // Top spending categories
  const catSpend = {};
  s.transactions.filter(t => t.type === 'expense').forEach(t => {
    if (t.category) catSpend[t.category] = (catSpend[t.category] || 0) + parseFloat(t.amount);
  });
  const topCategories = Object.entries(catSpend)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const maxCatSpend = topCategories[0]?.[1] || 1;

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-secondary" data-action="showTransactionModal()">+ Transaction</button>
        <button class="btn btn-primary" data-action="showTransferModal()">
          <svg viewBox="0 0 24 24"><path d="M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z"/></svg>
          Transfer
        </button>
      </div>
    </div>

    <div class="stats-strip">
      <div class="stat-card">
        <div class="stat-label">Net Worth</div>
        <div class="stat-value ${netWorth >= 0 ? 'accent' : 'red'}">${formatCurrency(netWorth, s.baseCurrency)}</div>
        <div class="stat-sub">Assets minus liabilities</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Assets</div>
        <div class="stat-value green">${formatCurrency(totalAssets, s.baseCurrency)}</div>
        <div class="stat-sub">${s.accounts.filter(a => a.type === 'asset').length} accounts</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Liabilities</div>
        <div class="stat-value red">${formatCurrency(totalLiabilities, s.baseCurrency)}</div>
        <div class="stat-sub">${s.accounts.filter(a => a.type === 'liability').length} accounts</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Cash Flow</div>
        <div class="stat-value ${cashFlow >= 0 ? 'green' : 'red'}">${cashFlow >= 0 ? '+' : ''}${formatCurrency(cashFlow, s.baseCurrency)}</div>
        <div class="stat-sub">Revenue minus expenses</div>
      </div>
    </div>

    <div class="content">
      <div class="dash-grid" style="gap:16px">
        <!-- Recent Transactions -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Recent Transactions</div>
            <button class="btn btn-ghost btn-sm" data-action="navigate('transactions')">View all</button>
          </div>
          ${recentTxs.length === 0
            ? `<div class="card-body"><p style="color:var(--text-3);font-size:13px">No transactions yet.</p></div>`
            : `<div class="table-wrap">
                <table>
                  <thead><tr><th>Date</th><th>Description</th><th>Amount</th></tr></thead>
                  <tbody>
                    ${recentTxs.map(t => {
                      const acc = s.accounts.find(a => a.id == t.accountId);
                      return `<tr>
                        <td class="td-muted" style="font-size:12px">${new Date(t.date).toLocaleDateString()}</td>
                        <td>
                          <div style="font-size:13px">${t.description || t.category || '—'}</div>
                          ${acc ? `<div style="font-size:11.5px;color:var(--text-3)">${acc.name}</div>` : ''}
                        </td>
                        <td class="td-mono ${t.type === 'income' ? 'td-green' : 'td-red'}" style="font-size:13px">
                          ${t.type === 'income' ? '+' : '-'}${formatCurrency(t.amount, t.currency)}
                        </td>
                      </tr>`;
                    }).join('')}
                  </tbody>
                </table>
              </div>`
          }
        </div>

        <!-- Budget Overview -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">Budget Overview</div>
            <button class="btn btn-ghost btn-sm" data-action="navigate('budgets')">Manage</button>
          </div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
            ${activeBudgets.length === 0
              ? `<p style="color:var(--text-3);font-size:13px">No active budgets.</p>`
              : activeBudgets.map(b => {
                  const spent = getCategorySpend(b.category, b.period);
                  const pct = b.limit > 0 ? Math.min((spent / b.limit) * 100, 100) : 0;
                  const isOver = spent > b.limit;
                  const isWarn = pct >= 80;
                  return `
                    <div>
                      <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                        <span style="font-size:13px;font-weight:500">${b.name}</span>
                        <span style="font-size:12px;font-family:var(--mono);color:${isOver ? 'var(--red)' : 'var(--text-2)'}">
                          ${formatCurrency(spent, b.currency)} / ${formatCurrency(b.limit, b.currency)}
                        </span>
                      </div>
                      <div class="progress-bar">
                        <div class="progress-fill ${isOver ? 'danger' : isWarn ? 'warning' : ''}" style="width:${pct}%"></div>
                      </div>
                    </div>
                  `;
                }).join('')
            }
          </div>
        </div>

        <!-- Accounts Summary -->
        <div class="card">
          <div class="card-header"><div class="card-title">Accounts Summary</div></div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Account</th><th>Type</th><th>Balance</th></tr></thead>
              <tbody>
                ${s.accounts.filter(a => a.active).map(acc => {
                  const bal = getAccountBalance(acc.id);
                  return `<tr>
                    <td>
                      <div style="font-size:13px;font-weight:500">${acc.icon || ''} ${acc.name}</div>
                      <div style="font-size:11.5px;color:var(--text-3)">${acc.currency}</div>
                    </td>
                    <td><span class="chip">${ACCOUNT_TYPES[acc.type]?.label || acc.type}</span></td>
                    <td class="td-mono" style="font-size:13px">${formatCurrency(bal, acc.currency)}</td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Top Categories -->
        <div class="card">
          <div class="card-header"><div class="card-title">Top Expense Categories</div></div>
          <div class="card-body" style="display:flex;flex-direction:column;gap:12px">
            ${topCategories.length === 0
              ? `<p style="color:var(--text-3);font-size:13px">No expense data yet.</p>`
              : topCategories.map(([cat, amt]) => {
                  const pct = (amt / maxCatSpend) * 100;
                  const catObj = s.categories.find(c => c.name === cat);
                  return `
                    <div>
                      <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                        <span style="font-size:13px">${catObj?.icon || '📂'} ${cat}</span>
                        <span style="font-size:12.5px;font-family:var(--mono);color:var(--red)">${formatCurrency(amt, s.baseCurrency)}</span>
                      </div>
                      <div class="progress-bar">
                        <div class="progress-fill danger" style="width:${pct}%"></div>
                      </div>
                    </div>
                  `;
                }).join('')
            }
          </div>
        </div>
      </div>
    </div>
  `;
}
// FinTrack — Settings Module

function renderExternalApiPage() {
  const s = getState();
  const page = document.getElementById('page-external-api');
  if (!page) return;

  const apiKey = s.apiKey || '';
  const formUrl = s.externalFormUrl || '';

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">External Access</div>
        <div class="page-subtitle">API token and external entry form link</div>
      </div>
    </div>

    <div class="content">
      <!-- API Token -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">API Token</div></div>
        <div class="card-body">
          <p style="font-size:13px;color:var(--text-2);margin-bottom:12px">
            Use this token to authenticate requests to the FinTrack external API.
            Include it as the <code>X-FinTrack-Token</code> header in every request.
            See the <a href="https://github.com/cloudsliberty/fintrack/blob/main/docs/MANUAL.md" target="_blank" rel="noopener noreferrer">usage manual</a> for details.
          </p>
          <div class="form-group" style="margin-bottom:12px">
            <label>Current Token</label>
            <div style="display:flex;gap:8px;align-items:center">
              <input id="ext-api-key" type="password" value="${escHtml(apiKey)}" readonly
                style="font-family:monospace;font-size:12.5px;flex:1">
              <button class="btn btn-secondary" id="ext-api-key-toggle" data-action="toggleApiKeyVisibility()">Show</button>
              <button class="btn btn-secondary" data-action="copyApiKey()">Copy</button>
            </div>
          </div>
          <div style="font-size:12px;color:var(--text-3);margin-bottom:16px">
            Keep this token secret. Anyone with this token can submit transactions on your behalf.
          </div>
          <button class="btn btn-danger" data-action="regenerateApiKey()">Regenerate Token</button>
        </div>
      </div>

      <!-- External Form Link -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">External Entry Form</div></div>
        <div class="card-body">
          <p style="font-size:13px;color:var(--text-2);margin-bottom:12px">
            Share this link to allow quick transaction entry without logging in to Nextcloud.
            The form uses your API token for authentication.
          </p>
          <div class="form-group" style="margin-bottom:12px">
            <label>Form URL</label>
            <div style="display:flex;gap:8px;align-items:center">
              <input id="ext-form-url" type="text" value="${escHtml(formUrl)}" readonly
                style="font-family:monospace;font-size:12px;flex:1">
              <button class="btn btn-secondary" data-action="copyFormUrl()">Copy</button>
            </div>
          </div>
          ${formUrl ? `<a href="${escHtml(formUrl)}" target="_blank" class="btn btn-primary" style="display:inline-block">Open Form</a>` : ''}
        </div>
      </div>

      <!-- Manual -->
      <div class="card">
        <div class="card-header"><div class="card-title">Usage Manual</div></div>
        <div class="card-body">
          <p style="font-size:13px;color:var(--text-2);margin-bottom:12px">
            Full documentation for the external API — endpoints, request/response formats, and examples —
            is maintained on GitHub rather than duplicated here, so it stays in sync with the app.
          </p>
          <a href="https://github.com/cloudsliberty/fintrack/blob/main/docs/MANUAL.md" target="_blank" rel="noopener noreferrer" class="btn btn-secondary" style="display:inline-flex;align-items:center;gap:8px;text-decoration:none">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.09 3.29 9.4 7.86 10.93.57.1.79-.25.79-.55 0-.27-.01-1.16-.02-2.11-3.2.7-3.88-1.36-3.88-1.36-.52-1.34-1.28-1.69-1.28-1.69-1.04-.72.08-.7.08-.7 1.16.08 1.76 1.19 1.76 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.56-.29-5.25-1.28-5.25-5.71 0-1.26.45-2.29 1.19-3.09-.12-.29-.52-1.47.11-3.06 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.79 0c2.21-1.49 3.18-1.18 3.18-1.18.63 1.59.23 2.77.11 3.06.74.8 1.19 1.83 1.19 3.09 0 4.44-2.7 5.42-5.27 5.7.41.36.78 1.06.78 2.14 0 1.55-.01 2.79-.01 3.17 0 .3.21.66.8.55A10.53 10.53 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>
            Read the Manual on GitHub
          </a>
        </div>
      </div>
    </div>
  `;
}

// Token stays masked (type="password") until the person explicitly asks to
// see it — a lightweight guard against shoulder-surfing / screen-share leaks.
window.toggleApiKeyVisibility = function () {
  const input = document.getElementById('ext-api-key');
  const btn = document.getElementById('ext-api-key-toggle');
  if (!input || !btn) return;
  const revealing = input.type === 'password';
  input.type = revealing ? 'text' : 'password';
  btn.textContent = revealing ? 'Hide' : 'Show';
};

window.copyApiKey = function () {
  const el = document.getElementById('ext-api-key');
  if (el) { navigator.clipboard.writeText(el.value); showToast('Token copied', 'success'); }
};

window.copyFormUrl = function () {
  const el = document.getElementById('ext-form-url');
  if (el) { navigator.clipboard.writeText(el.value); showToast('URL copied', 'success'); }
};

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderSettingsPage() {
  const s = getState();
  const page = document.getElementById('page-settings');

  const txCount = s.transactions.length;
  const accCount = s.accounts.length;
  const dataSize = (JSON.stringify(s).length / 1024).toFixed(1);

  page.innerHTML = `
    <div class="page-header">
      <div>
        <div class="page-title">Settings</div>
        <div class="page-subtitle">Application preferences and data management</div>
      </div>
    </div>

    <div class="content">
      <!-- General Settings -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">General Preferences</div></div>
        <div class="card-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Base / Display Currency</label>
              <select id="set-basecur">
                ${s.currencies.map(c => `<option value="${c.code}" ${s.baseCurrency === c.code ? 'selected' : ''}>${c.code} — ${c.name}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label>Date Format</label>
              <select id="set-datefmt">
                <option value="MM/DD/YYYY" ${s.settings?.date_format === 'MM/DD/YYYY' ? 'selected' : ''}>MM/DD/YYYY (US)</option>
                <option value="DD/MM/YYYY" ${s.settings?.date_format === 'DD/MM/YYYY' ? 'selected' : ''}>DD/MM/YYYY (EU)</option>
                <option value="YYYY-MM-DD" ${s.settings?.date_format === 'YYYY-MM-DD' ? 'selected' : ''}>YYYY-MM-DD (ISO)</option>
              </select>
            </div>
            <div class="form-group">
              <label>Start of Week</label>
              <select id="set-weekstart">
                <option value="sunday" ${(!s.settings?.week_start || s.settings?.week_start === 'sunday') ? 'selected' : ''}>Sunday</option>
                <option value="monday" ${s.settings?.week_start === 'monday' ? 'selected' : ''}>Monday</option>
              </select>
            </div>
            <div class="form-group">
              <label>Fiscal Year Start Month</label>
              <select id="set-fymonth">
                ${['January','February','March','April','May','June','July','August','September','October','November','December']
                  .map((m, i) => `<option value="${i}" ${String(s.settings?.fy_month ?? 0) === String(i) ? 'selected' : ''}>${m}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label>Default Transaction Type</label>
              <select id="set-txdefault">
                <option value="expense" ${(!s.settings?.default_tx_type || s.settings?.default_tx_type === 'expense') ? 'selected' : ''}>Expense</option>
                <option value="income" ${s.settings?.default_tx_type === 'income' ? 'selected' : ''}>Income</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button class="btn btn-primary" data-action="saveSettings()">Save Preferences</button>
          </div>
        </div>
      </div>

      <!-- Data Stats -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">Data Overview</div></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px">
            ${[
              ['Accounts', accCount],
              ['Transactions', txCount],
              ['Transfers', s.transfers.length],
              ['Budgets', s.budgets.length],
              ['Categories', s.categories.length],
              ['Tags', s.tags.length],
              ['Currencies', s.currencies.length],
              ['Storage Used', `${dataSize} KB`],
            ].map(([label, val]) => `
              <div style="background:var(--bg);border-radius:6px;padding:12px 14px;text-align:center">
                <div style="font-size:20px;font-weight:700;color:var(--accent)">${val}</div>
                <div style="font-size:11.5px;color:var(--text-3);margin-top:2px">${label}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Categories & Tags -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">Categories &amp; Tags</div></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div>
              <div style="font-size:13.5px;font-weight:600;margin-bottom:6px">Export</div>
              <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Download your categories and tags as a JSON file.</p>
              <button class="btn btn-secondary" data-action="exportCategoriesAndTags()">Export Categories &amp; Tags</button>
            </div>
            <div>
              <div style="font-size:13.5px;font-weight:600;margin-bottom:6px">Import</div>
              <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Add categories/tags from a previously exported file. Existing ones are left untouched.</p>
              <label class="btn btn-secondary" style="cursor:pointer">
                Import Categories &amp; Tags
                <input type="file" accept=".json" style="display:none" data-change="importCategoriesAndTags(el)">
              </label>
            </div>
          </div>
          <div class="section-divider"></div>
          <div>
            <div style="font-size:13.5px;font-weight:600;margin-bottom:6px">Starter Set</div>
            <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Create a set of common categories (Groceries, Rent, Salary, etc.) and tags to get started quickly.</p>
            <button class="btn btn-secondary" data-action="createDefaultCategoriesAndTags()">Create Default Categories &amp; Tags</button>
          </div>
        </div>
      </div>

      <!-- Data Management -->
      <div class="card" style="margin-bottom:16px">
        <div class="card-header"><div class="card-title">Data Management</div></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div>
              <div style="font-size:13.5px;font-weight:600;margin-bottom:6px">Backup Data</div>
              <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Export all your data as a JSON backup file.</p>
              <button class="btn btn-secondary" data-action="exportJSON()">Download Backup</button>
            </div>
            <div>
              <div style="font-size:13.5px;font-weight:600;margin-bottom:6px">Restore from Backup</div>
              <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Restore all data from a previously exported backup.</p>
              <label class="btn btn-secondary" style="cursor:pointer">
                Restore Backup
                <input type="file" accept=".json" style="display:none" data-change="restoreBackup(el)">
              </label>
            </div>
          </div>
          <div class="section-divider"></div>
          <div>
            <div style="font-size:13.5px;font-weight:600;margin-bottom:6px">Import Transactions from CSV</div>
            <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Import a batch of transactions from a CSV file into one account.</p>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button class="btn btn-secondary" data-action="showImportCsvModal()">Import CSV</button>
              <button class="btn btn-ghost" data-action="downloadCsvTemplate()">Download Template</button>
            </div>
          </div>
          <div class="section-divider"></div>
          <div>
            <div style="font-size:13.5px;font-weight:600;color:var(--red);margin-bottom:6px">Danger Zone</div>
            <p style="font-size:13px;color:var(--text-2);margin-bottom:10px">Permanently delete all FinTrack data. This cannot be undone.</p>
            <button class="btn btn-danger" data-action="confirmReset()">Reset All Data</button>
          </div>
        </div>
      </div>

      <!-- About -->
      <div class="card">
        <div class="card-header"><div class="card-title">About FinTrack</div></div>
        <div class="card-body">
          <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px">
            <div style="width:48px;height:48px;background:var(--accent);border-radius:12px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:16px">FT</div>
            <div>
              <div style="font-size:16px;font-weight:700">FinTrack</div>
              <div style="font-size:12.5px;color:var(--text-3)">Personal Finance Manager v1.7.7</div>
            </div>
          </div>
          <div style="font-size:13px;color:var(--text-2);line-height:1.7">
            FinTrack is a full-featured personal finance application with multi-currency support, 
            asset/expense/revenue/liability accounts, investment tracking, budget tracking, recurring transactions, 
            external API access, and comprehensive reporting.
          </div>
          <div style="font-size:12.5px;color:var(--text-3);margin-top:10px">
            Live currency conversion rates are fetched using the free
            <a href="https://frankfurter.dev" target="_blank" rel="noopener noreferrer">Frankfurter API</a>
            (<span class="td-mono">api.frankfurter.dev</span>) — no key required, no data leaves your Nextcloud server
            except the currency codes being looked up.
          </div>
          <div style="display:flex;align-items:center;gap:12px;margin-top:16px;flex-wrap:wrap">
            <a href="https://github.com/cloudsliberty/fintrack" target="_blank" rel="noopener noreferrer" class="btn btn-secondary" style="display:inline-flex;align-items:center;gap:8px;text-decoration:none">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.09 3.29 9.4 7.86 10.93.57.1.79-.25.79-.55 0-.27-.01-1.16-.02-2.11-3.2.7-3.88-1.36-3.88-1.36-.52-1.34-1.28-1.69-1.28-1.69-1.04-.72.08-.7.08-.7 1.16.08 1.76 1.19 1.76 1.19 1.03 1.76 2.7 1.25 3.36.96.1-.75.4-1.25.73-1.54-2.56-.29-5.25-1.28-5.25-5.71 0-1.26.45-2.29 1.19-3.09-.12-.29-.52-1.47.11-3.06 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.79 0c2.21-1.49 3.18-1.18 3.18-1.18.63 1.59.23 2.77.11 3.06.74.8 1.19 1.83 1.19 3.09 0 4.44-2.7 5.42-5.27 5.7.41.36.78 1.06.78 2.14 0 1.55-.01 2.79-.01 3.17 0 .3.21.66.8.55A10.53 10.53 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>
              View on GitHub
            </a>
            <a href="https://www.paypal.me/jaleel1618" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:8px;background:#ffc439;color:#111;font-weight:700;font-size:13px;padding:8px 16px;border-radius:var(--ft-radius,6px);text-decoration:none">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="#111"><path d="M7.4 21.6h-3a.5.5 0 0 1-.5-.6l2.8-17.6a.7.7 0 0 1 .7-.6h6.8c3.2 0 5.4 1.5 4.9 4.7-.5 3.6-3 5.2-6.3 5.2H10a.7.7 0 0 0-.7.6l-.9 5.7-1 2.6zm5.6-12.6c1.7 0 2.6-.8 2.8-2.3.2-1.5-.6-2.1-2.2-2.1h-2l-.7 4.4h2.1z"/></svg>
              Donate via PayPal
            </a>
          </div>
        </div>
      </div>

      <!-- About the Developer -->
      <div class="card" style="margin-top:16px">
        <div class="card-header"><div class="card-title">About the Developer</div></div>
        <div class="card-body">
          <div style="font-size:13px;color:var(--text-2);line-height:1.7">
            This program was designed and developed by Abdul Jaleel Adenpulan, a technology enthusiast from Kondotty, Kerala, India. With a strong passion for coding, automation, and project design, he enjoys creating practical software solutions that simplify daily tasks and improve productivity.
          </div>
        </div>
      </div>
    </div>
  `;
}

function saveSettings() {
  if (typeof window._ftSaveSettings === 'function') { window._ftSaveSettings(); return; }
  const state = getState();
  if (!state.settings) state.settings = {};
  state.settings.date_format = document.getElementById('set-datefmt').value;
  state.settings.week_start = document.getElementById('set-weekstart').value;
  state.settings.fy_month = parseInt(document.getElementById('set-fymonth').value);
  state.settings.default_tx_type = document.getElementById('set-txdefault').value;
  state.baseCurrency = document.getElementById('set-basecur').value;
  saveState();
  showToast('Settings saved', 'success');
}

function restoreBackup(input) {
  const state = getState();
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      if (!imported.accounts || !imported.transactions) {
        showToast('Invalid backup file', 'error'); return;
      }
      Object.assign(state, imported);
      saveState();
      showToast('Backup restored successfully', 'success');
      renderSettingsPage();
      renderDashboard();
    } catch {
      showToast('Failed to restore backup', 'error');
    }
  };
  reader.readAsText(file);
}

// ── CSV Import ──

// Holds the parsed rows from the last selected CSV file, keyed nowhere
// persistent — this is just transient state for the open import modal.
let _csvImportRows = [];

const CSV_TEMPLATE_HEADERS = ['date', 'type', 'amount', 'description', 'category', 'tags', 'notes', 'conversionRate'];
const CSV_TEMPLATE_ROWS = [
  ['2026-01-05', 'expense', '42.50', 'Grocery shopping', 'Groceries', 'food;weekly', 'Bought vegetables and fruit', ''],
  ['2026-01-07', 'income', '1500.00', 'Monthly salary', 'Salary', '', '', ''],
  ['2026-01-10', 'expense', '9.99', 'Streaming subscription', 'Entertainment', 'subscriptions', '', ''],
];

function buildCsvTemplateText() {
  const esc = v => '"' + String(v).replace(/"/g, '""') + '"';
  const lines = [CSV_TEMPLATE_HEADERS.join(',')];
  CSV_TEMPLATE_ROWS.forEach(row => lines.push(row.map(esc).join(',')));
  return lines.join('\n');
}

function downloadCsvTemplate() {
  const blob = new Blob([buildCsvTemplateText()], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'fintrack-import-template.csv';
  a.click();
}

/**
 * Minimal RFC4180-ish CSV parser: handles quoted fields, embedded commas,
 * and escaped quotes ("") inside quoted fields. Good enough for the small,
 * hand-edited or spreadsheet-exported files this feature targets.
 */
function parseCSV(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  const pushField = () => { row.push(field); field = ''; };
  const pushRow = () => { pushField(); rows.push(row); row = []; };

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else { inQuotes = false; }
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      pushField();
    } else if (c === '\r') {
      // ignore, handled by \n
    } else if (c === '\n') {
      pushRow();
    } else {
      field += c;
    }
  }
  // Final field/row if the file doesn't end with a newline
  if (field.length > 0 || row.length > 0) pushRow();

  if (rows.length === 0) return [];
  const headers = rows[0].map(h => h.trim().toLowerCase());
  return rows.slice(1)
    .filter(r => r.some(cell => cell.trim() !== ''))
    .map(r => {
      const obj = {};
      headers.forEach((h, idx) => { obj[h] = (r[idx] || '').trim(); });
      return obj;
    });
}

function showImportCsvModal() {
  const s = getState();
  _csvImportRows = [];

  if (s.accounts.length === 0) {
    showToast('Add an account first', 'error');
    return;
  }

  openModal('Import Transactions from CSV', `
    <div class="form-grid cols-1">
      <div class="form-grid">
        <div class="form-group full">
          <label>Import into Account *</label>
          <select id="csv-import-account">
            ${s.accounts.map(a => `<option value="${a.id}">${a.icon || ''} ${a.name} (${a.currency})</option>`).join('')}
          </select>
        </div>
        <div class="form-group full">
          <label>CSV File</label>
          <input type="file" id="csv-import-file" accept=".csv" data-change="handleCsvFileSelect(el)">
        </div>
        <div class="form-group full">
          <p style="font-size:12.5px;color:var(--text-3);line-height:1.6">
            Expected columns: <code>date, type, amount, description, category, tags, notes, conversionRate</code>.
            <code>type</code> is <code>income</code> or <code>expense</code>; <code>tags</code> are semicolon-separated.
            <code>conversionRate</code> is optional — only needed when this account's currency differs from your
            base currency, and lets each imported row keep the exchange rate that applied on its own date
            (1 account-currency unit = <code>conversionRate</code> base-currency units). Leave it blank to use the
            currency's current rate on file.
            <a href="#" data-action="downloadCsvTemplate()">Download a template</a>.
          </p>
        </div>
        <div class="form-group full" id="csv-import-preview" style="font-size:13px;color:var(--text-2)"></div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-primary" id="csv-import-btn" data-action="importCsvTransactions()" disabled>Import</button>
      </div>
    </div>
  `);
}

function handleCsvFileSelect(input) {
  const file = input.files[0];
  const preview = document.getElementById('csv-import-preview');
  const importBtn = document.getElementById('csv-import-btn');
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      _csvImportRows = parseCSV(e.target.result);
      if (_csvImportRows.length === 0) {
        preview.textContent = 'No transactions found in this file.';
        importBtn.disabled = true;
        return;
      }
      preview.textContent = `${_csvImportRows.length} transaction(s) ready to import.`;
      importBtn.disabled = false;
    } catch (err) {
      preview.textContent = 'Could not read this file — please check it is a valid CSV.';
      importBtn.disabled = true;
    }
  };
  reader.readAsText(file);
}

function importCsvTransactions() {
  const accountId = document.getElementById('csv-import-account').value;
  if (!accountId) { showToast('Select an account', 'error'); return; }
  if (_csvImportRows.length === 0) { showToast('Choose a CSV file first', 'error'); return; }

  if (typeof window._ftImportCsvTransactions === 'function') {
    window._ftImportCsvTransactions(accountId, _csvImportRows);
    return;
  }

  // Standalone fallback — validate and push rows straight into local state.
  const state = getState();
  const acc = state.accounts.find(a => a.id == accountId);
  let imported = 0;
  const errors = [];

  _csvImportRows.forEach((row, i) => {
    const type = (row.type || 'expense').toLowerCase();
    const amount = parseFloat(row.amount);
    if (!amount || amount <= 0) { errors.push(`Row ${i + 2}: invalid amount`); return; }
    if (!row.date || isNaN(new Date(row.date).getTime())) { errors.push(`Row ${i + 2}: invalid date`); return; }

    const currency = acc ? acc.currency : 'USD';
    let conversionRate = null;
    if (currency !== state.baseCurrency) {
      const rowRate = parseFloat(row.conversionrate || row.conversion_rate || row.rate);
      if (rowRate > 0) {
        conversionRate = rowRate;
        const cur = state.currencies.find(c => c.code === currency);
        if (cur) cur.rate = rowRate;
      } else {
        // No rate given for this row — fall back to whatever's on file.
        conversionRate = getRate(currency, state.baseCurrency);
      }
    }

    state.transactions.push({
      id: generateId('tx'),
      accountId,
      type: ['income', 'expense'].includes(type) ? type : 'expense',
      amount,
      currency,
      conversionRate,
      description: row.description || '',
      category: row.category || '',
      tags: (row.tags || '').split(';').map(t => t.trim()).filter(Boolean),
      notes: row.notes || '',
      date: new Date(row.date).toISOString(),
      source: 'import',
      created: new Date().toISOString(),
    });
    imported++;
  });

  saveState();
  closeModal();
  showToast(`Imported ${imported} transaction(s)${errors.length ? `, ${errors.length} skipped` : ''}`, errors.length ? 'error' : 'success');
  refreshCurrentPage();
}

function confirmReset() {
  openModal('Reset All Data', `
    <div style="text-align:center;padding:10px 0">
      <div style="font-size:40px;margin-bottom:12px">⚠️</div>
      <div style="font-size:15px;font-weight:600;margin-bottom:8px">Are you sure?</div>
      <p style="font-size:13.5px;color:var(--text-2);line-height:1.6;margin-bottom:20px">
        This will permanently delete ALL your accounts, transactions, budgets, and settings.<br>
        This action <strong>cannot be undone</strong>.
      </p>
      <div style="display:flex;gap:10px;justify-content:center">
        <button class="btn btn-secondary" data-action="closeModal()">Cancel</button>
        <button class="btn btn-danger" data-action="resetAllData()">Yes, Delete Everything</button>
      </div>
    </div>
  `);
}

function resetAllData() {
  if (typeof window._ftResetAllData === 'function') { window._ftResetAllData(); return; }
  // In Nextcloud mode, data reset requires server-side action.
  if (typeof showToast === 'function') {
    showToast('To reset: use occ app:disable fintrack && occ app:enable fintrack', 'error');
  }
}

