// FinTrack — External Entry Form JS
// Config is read from data attributes on #ft-card to avoid inline JS (CSP compliance).
// No Nextcloud session or CSRF token required — authentication is via X-FinTrack-Token header.
(function () {
'use strict';

const card         = document.getElementById('ft-card');
const TOKEN        = card.dataset.token        || '';
const SUBMIT_URL   = card.dataset.submit       || '';
const ACCOUNTS_URL = card.dataset.accounts     || '';
const CATS_URL     = card.dataset.categories   || '';
const TAGS_URL     = card.dataset.tags         || '';

let ACCOUNTS = [];
let CATEGORIES = [];
let SAVED_TAGS = [];

// Set today's date as default
document.getElementById('date').value = new Date().toISOString().split('T')[0];

// ── Simple fuzzy (subsequence) matcher, mirrors the main app's combobox ──
function fuzzyMatch(needle, haystack) {
	needle = (needle || '').toLowerCase();
	haystack = (haystack || '').toLowerCase();
	if (!needle) return true;
	let i = 0;
	for (let j = 0; j < haystack.length && i < needle.length; j++) {
		if (haystack[j] === needle[i]) i++;
	}
	return i === needle.length;
}

function wireCombobox(searchId, hiddenId, ddId, getOptions, onSelect) {
	const search = document.getElementById(searchId);
	const hidden = document.getElementById(hiddenId);
	const dd     = document.getElementById(ddId);

	function render(query) {
		const options = getOptions();
		const matches = options.filter(function (o) { return fuzzyMatch(query, o.label); }).slice(0, 60);
		if (!matches.length) {
			dd.innerHTML = '<div class="combo-empty">No matches</div>';
		} else {
			dd.innerHTML = matches.map(function (o) {
				return '<div class="combo-opt" data-value="' + o.value + '">' + o.label + '</div>';
			}).join('');
		}
		dd.style.display = 'block';
	}

	search.addEventListener('input', function () { render(search.value); });
	search.addEventListener('focus', function () { render(search.value); });
	search.addEventListener('blur', function () { setTimeout(function () { dd.style.display = 'none'; }, 150); });
	dd.addEventListener('click', function (e) {
		const opt = e.target.closest('.combo-opt');
		if (!opt) return;
		const value = opt.dataset.value;
		const options = getOptions();
		const found = options.find(function (o) { return String(o.value) === String(value); });
		hidden.value = value;
		search.value = found ? found.label : '';
		dd.style.display = 'none';
		if (onSelect) onSelect(value);
	});
}

wireCombobox('account-search', 'account', 'account-dd', function () {
	return ACCOUNTS.map(function (a) {
		return { value: a.id, label: (a.icon ? a.icon + ' ' : '') + a.name + ' (' + a.currency + ')' };
	});
});

wireCombobox('cat-search', 'cat', 'cat-dd', function () {
	return CATEGORIES.map(function (c) {
		return { value: c.name, label: (c.icon ? c.icon + ' ' : '') + c.name };
	});
});

// ── Tag autosuggest — free-text comma-separated field with a dropdown of
// already-saved tags matching whatever's being typed after the last comma ──
(function wireTagAutosuggest() {
	const input = document.getElementById('tags');
	const dd    = document.getElementById('tags-dd');

	function currentFragment() {
		const parts = input.value.split(',');
		return parts[parts.length - 1].trim().toLowerCase();
	}

	function render() {
		const frag = currentFragment();
		const already = input.value.split(',').slice(0, -1).map(function (t) { return t.trim().toLowerCase(); });
		const matches = SAVED_TAGS
			.filter(function (t) { return !already.includes(t.toLowerCase()); })
			.filter(function (t) { return frag === '' || t.toLowerCase().includes(frag); })
			.slice(0, 20);
		if (!matches.length) { dd.style.display = 'none'; return; }
		dd.innerHTML = matches.map(function (t) {
			return '<div class="combo-opt" data-tag="' + t + '">' + t + '</div>';
		}).join('');
		dd.style.display = 'block';
	}

	input.addEventListener('input', render);
	input.addEventListener('focus', render);
	input.addEventListener('blur', function () { setTimeout(function () { dd.style.display = 'none'; }, 150); });
	dd.addEventListener('click', function (e) {
		const opt = e.target.closest('.combo-opt');
		if (!opt) return;
		const parts = input.value.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
		parts.pop();
		parts.push(opt.dataset.tag);
		input.value = parts.join(', ') + ', ';
		dd.style.display = 'none';
		input.focus();
	});
})();

// ── Type toggle ──
let currentType = 'expense';
document.getElementById('btn-expense').addEventListener('click', function () {
	setType('expense', this, document.getElementById('btn-income'));
});
document.getElementById('btn-income').addEventListener('click', function () {
	setType('income', this, document.getElementById('btn-expense'));
});

function setType(type, activeBtn, inactiveBtn) {
	currentType = type;
	document.getElementById('txtype').value = type;
	activeBtn.className   = 'tbtn a' + type[0];
	inactiveBtn.className = 'tbtn';
}

// ── Load accounts, categories and tags ──
async function load() {
	try {
		const headers = {
			'X-FinTrack-Token':  TOKEN,
			'X-Requested-With':  'XMLHttpRequest',
		};
		const [accs, cats, tags] = await Promise.all([
			fetch(ACCOUNTS_URL,  { headers }).then(checkResponse),
			fetch(CATS_URL,      { headers }).then(checkResponse),
			TAGS_URL ? fetch(TAGS_URL, { headers }).then(checkResponse).catch(function () { return []; }) : Promise.resolve([]),
		]);

		// Server already restricts this to active accounts only, so inactive
		// accounts never appear as selectable options here.
		ACCOUNTS   = accs || [];
		CATEGORIES = cats || [];
		SAVED_TAGS = tags || [];

		document.getElementById('loading').style.display = 'none';
		document.getElementById('form').style.display    = 'block';
	} catch (e) {
		document.getElementById('loading').textContent = 'Failed to load — check your link. ' + (e.message || '');
	}
}

// ── Quick-add category ──
const catQuickAddToggle = document.getElementById('cat-quickadd-toggle');
const catQuickAddPanel  = document.getElementById('cat-quickadd');
const catQuickAddSave   = document.getElementById('cat-quickadd-save');

catQuickAddToggle.addEventListener('click', function (e) {
	e.preventDefault();
	const showing = catQuickAddPanel.style.display !== 'none';
	catQuickAddPanel.style.display = showing ? 'none' : 'block';
	if (!showing) document.getElementById('cat-quickadd-name').focus();
});

catQuickAddSave.addEventListener('click', async function () {
	const name = document.getElementById('cat-quickadd-name').value.trim();
	const type = document.getElementById('cat-quickadd-type').value;
	if (!name) { showErr('Enter a category name'); return; }

	try {
		const res = await fetch(CATS_URL, {
			method:  'POST',
			headers: {
				'Content-Type':     'application/json',
				'X-FinTrack-Token': TOKEN,
				'X-Requested-With': 'XMLHttpRequest',
			},
			body: JSON.stringify({ token: TOKEN, name, type }),
		});
		const cat = await checkResponse(res);

		CATEGORIES.push(cat);
		const label = (cat.icon ? cat.icon + ' ' : '') + cat.name;
		document.getElementById('cat').value = cat.name;
		document.getElementById('cat-search').value = label;

		document.getElementById('cat-quickadd-name').value = '';
		catQuickAddPanel.style.display = 'none';
	} catch (e) {
		showErr(e.message || 'Failed to add category');
	}
});

async function checkResponse(res) {
	if (!res.ok) {
		const err = await res.json().catch(function () { return { error: res.statusText }; });
		throw new Error(err.error || res.statusText);
	}
	return res.json();
}

// ── Submit ──
document.getElementById('submit-btn').addEventListener('click', submitForm);

async function submitForm() {
	const amount = parseFloat(document.getElementById('amount').value);
	const acct   = document.getElementById('account').value;

	if (!amount || amount <= 0) { showErr('Enter a valid amount'); return; }
	if (!acct)                   { showErr('Select an account');   return; }

	const payload = {
		token:       TOKEN,
		type:        currentType,
		accountId:   parseInt(acct, 10),
		amount:      amount,
		description: document.getElementById('desc').value.trim(),
		category:    document.getElementById('cat').value,
		tags:        document.getElementById('tags').value
			.split(',').map(function (t) { return t.trim(); }).filter(Boolean),
		notes:       document.getElementById('notes').value.trim(),
		date:        document.getElementById('date').value,
	};

	try {
		const res  = await fetch(SUBMIT_URL, {
			method:  'POST',
			headers: {
				'Content-Type':     'application/json',
				'X-FinTrack-Token': TOKEN,
				'X-Requested-With': 'XMLHttpRequest',
			},
			body: JSON.stringify(payload),
		});
		const data = await res.json();
		if (!res.ok) { showErr(data.error || 'Submission failed'); return; }

		// New tags are auto-saved server-side (TransactionService); reflect
		// them locally too so they're suggested immediately without a reload.
		payload.tags.forEach(function (t) { if (!SAVED_TAGS.includes(t)) SAVED_TAGS.push(t); });

		// Reset form fields
		document.getElementById('amount').value = '';
		document.getElementById('desc').value   = '';
		document.getElementById('notes').value  = '';
		document.getElementById('tags').value   = '';

		const ok = document.getElementById('ok');
		ok.style.display = 'block';
		setTimeout(function () { ok.style.display = 'none'; }, 4000);
	} catch (e) {
		showErr('Network error — please try again');
	}
}

function showErr(msg) {
	const el = document.getElementById('err');
	el.textContent   = msg;
	el.style.display = 'block';
	setTimeout(function () { el.style.display = 'none'; }, 4000);
}

load();
})();
